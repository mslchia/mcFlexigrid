/*
 * Flexigrid for jQuery -  v1.1
 *
 * Copyright (c) 2008 Paulo P. Marinas (code.google.com/p/flexigrid/)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 * 
 */
 
 /* 
 * Modified by MCCodes
 * Added flexicommand July 2013 
 * Added Flexilist Oct 2013
 * Added fleximodal Des 2013
 * Added flexiform Jan 2014 
 */

(function ($) {
    $.addFlex = function (t, p) {
        if (t.grid) return false; //return if already exist
        p = $.extend({ //apply default properties
            height: 200, //default height
            width: 'auto', //auto width
            striped: true, //apply odd even stripes
            novstripe: false,
            minwidth: 30, //min width of columns
            minheight: 80, //min height of columns
            resizable: true, //allow table resizing
            url: false, //URL if using data from AJAX
            method: 'POST', //data sending method
            dataType: 'xml', //type of data for AJAX, either xml or json
            errormsg: 'Connection Error',
            usepager: false,
            nowrap: true,
            page: 1, //current page
            total: 1, //total pages
            useRp: true, //use the results per page select box
            rp: 15, //results per page
            rpOptions: [10, 15, 20, 30, 50], //allowed per-page values 
            title: false,
            pagestat: 'Displaying {from} to {to} of {total} items',
            pagetext: 'Page',
            outof: 'of',
            findtext: 'Find',
            searchbtn: 'Search',
            procmsg: 'Processing, please wait ...',
            query: '',
            qtype: '',
            nomsg: 'No items',
            minColToggle: 1, //minimum allowed column to be hidden
            showToggleBtn: false, //show or hide column toggle popup
            hideOnSubmit: true,
            autoload: true,
            blockOpacity: 0.5,
            preProcess: false,
            onDragCol: false,
            onToggleCol: false,
            onChangeSort: false,
            onSuccess: false,
            onError: false,
            onSubmit: false, //using a custom populate function            
            flexilist: {
                url: '',
                dataType: 'json',
                rp: 5,
                width: '300px',
                height: 'auto', //should be auto or # pixels
                opacity: 0.5,
                bgcolor: "#000",
                pages: 0,  //total pages
                cpage: 1,  //current page
                npage: 1,  //new page
                total: 0,   //totalitems
                pagestat: "Page {current} of {total} Pages.",
                procmsg: 'Processing, please wait ...',
                nomsg: 'No items',
                errormsg: 'Connection Error',
                striped: true
            },
            flexiform: {
                url: '',
                dataType: 'json',
                title: '',
                description: '',
                width: '350px',
                height: 'auto',
                params: null,
                submitbtn: { use: true, display: 'Submit' },
                resetbtn: { use: false, display: 'Reset' }
            }
        }, p);

        $(t).show() //show if hidden
			.attr({
			    cellPadding: 0,
			    cellSpacing: 0,
			    border: 0
			}) //remove padding and spacing
			.removeAttr('width'); //remove width properties
        //create grid class
        var g = {
            hset: {},
            rePosDrag: function () {
                var cdleft = 0 - this.hDiv.scrollLeft;
                if (this.hDiv.scrollLeft > 0) cdleft -= Math.floor(p.cgwidth / 2);
                $(g.cDrag).css({
                    top: g.hDiv.offsetTop + 1
                });
                var cdpad = this.cdpad;
                $('div', g.cDrag).hide();
                $('thead tr:first th:visible', this.hDiv).each(function () {
                    var n = $('thead tr:first th:visible', g.hDiv).index(this);
                    var cdpos = parseInt($('div', this).width());
                    if (cdleft == 0) cdleft -= Math.floor(p.cgwidth / 2);
                    cdpos = cdpos + cdleft + cdpad;
                    if (isNaN(cdpos)) {
                        cdpos = 0;
                    }
                    $('div:eq(' + n + ')', g.cDrag).css({
                        'left': cdpos + 'px'
                    }).show();
                    cdleft = cdpos;
                });
            },
            fixHeight: function (newH) {
                newH = false;
                if (!newH) newH = $(g.bDiv).height();
                var hdHeight = $(this.hDiv).height();
                $('div', this.cDrag).each(
					function () {
					    $(this).height(newH + hdHeight);
					}
				);
                var nd = parseInt($(g.nDiv).height());
                if (nd > newH) $(g.nDiv).height(newH).width(200);
                else $(g.nDiv).height('auto').width('auto');
                $(g.block).css({
                    height: newH,
                    marginBottom: (newH * -1)
                });
                var hrH = g.bDiv.offsetTop + newH;
                if (p.height != 'auto' && p.resizable) hrH = g.vDiv.offsetTop;
                $(g.rDiv).css({
                    height: hrH
                });
            },
            dragStart: function (dragtype, e, obj) { //default drag function start
                if (dragtype == 'colresize') {//column resize
                    $(g.nDiv).hide();
                    $(g.nBtn).hide();
                    var n = $('div', this.cDrag).index(obj);
                    var ow = $('th:visible div:eq(' + n + ')', this.hDiv).width();
                    $(obj).addClass('dragging').siblings().hide();
                    $(obj).prev().addClass('dragging').show();
                    this.colresize = {
                        startX: e.pageX,
                        ol: parseInt(obj.style.left),
                        ow: ow,
                        n: n
                    };
                    $('body').css('cursor', 'col-resize');
                } else if (dragtype == 'vresize') {//table resize
                    var hgo = false;
                    $('body').css('cursor', 'row-resize');
                    if (obj) {
                        hgo = true;
                        $('body').css('cursor', 'col-resize');
                    }
                    this.vresize = {
                        h: p.height,
                        sy: e.pageY,
                        w: p.width,
                        sx: e.pageX,
                        hgo: hgo
                    };
                } else if (dragtype == 'colMove') {//column header drag
                    $(g.nDiv).hide();
                    $(g.nBtn).hide();
                    this.hset = $(this.hDiv).offset();
                    this.hset.right = this.hset.left + $('table', this.hDiv).width();
                    this.hset.bottom = this.hset.top + $('table', this.hDiv).height();
                    this.dcol = obj;
                    this.dcoln = $('th', this.hDiv).index(obj);
                    this.colCopy = document.createElement("div");
                    this.colCopy.className = "colCopy";
                    this.colCopy.innerHTML = obj.innerHTML;
                    if ($.browser.msie) {
                        this.colCopy.className = "colCopy ie";
                    }
                    $(this.colCopy).css({
                        position: 'absolute',
                        float: 'left',
                        display: 'none',
                        textAlign: obj.align
                    });
                    $('body').append(this.colCopy);
                    $(this.cDrag).hide();
                }
                //$('body').noSelect();
            },
            dragMove: function (e) {
                if (this.colresize) {//column resize
                    var n = this.colresize.n;
                    var diff = e.pageX - this.colresize.startX;
                    var nleft = this.colresize.ol + diff;
                    var nw = this.colresize.ow + diff;
                    if (nw > p.minwidth) {
                        $('div:eq(' + n + ')', this.cDrag).css('left', nleft);
                        this.colresize.nw = nw;
                    }
                } else if (this.vresize) {//table resize
                    var v = this.vresize;
                    var y = e.pageY;
                    var diff = y - v.sy;
                    if (!p.defwidth) p.defwidth = p.width;
                    if (p.width != 'auto' && !p.nohresize && v.hgo) {
                        var x = e.pageX;
                        var xdiff = x - v.sx;
                        var newW = v.w + xdiff;
                        if (newW > p.defwidth) {
                            this.gDiv.style.width = newW + 'px';
                            p.width = newW;
                        }
                    }
                    var newH = v.h + diff;
                    if ((newH > p.minheight || p.height < p.minheight) && !v.hgo) {
                        this.bDiv.style.height = newH + 'px';
                        p.height = newH;
                        this.fixHeight(newH);
                    }
                    v = null;
                } else if (this.colCopy) {
                    $(this.dcol).addClass('thMove').removeClass('thOver');
                    if (e.pageX > this.hset.right || e.pageX < this.hset.left || e.pageY > this.hset.bottom || e.pageY < this.hset.top) {
                        //this.dragEnd();
                        $('body').css('cursor', 'move');
                    } else {
                        $('body').css('cursor', 'pointer');
                    }
                    $(this.colCopy).css({
                        top: e.pageY + 10,
                        left: e.pageX + 20,
                        display: 'block'
                    });
                }
            },
            dragEnd: function () {
                if (this.colresize) {
                    var n = this.colresize.n;
                    var nw = this.colresize.nw;
                    $('th:visible div:eq(' + n + ')', this.hDiv).css('width', nw);
                    $('tr', this.bDiv).each(
						function () {
						    $('td:visible div:eq(' + n + ')', this).css('width', nw);
						}
					);
                    this.hDiv.scrollLeft = this.bDiv.scrollLeft;
                    $('div:eq(' + n + ')', this.cDrag).siblings().show();
                    $('.dragging', this.cDrag).removeClass('dragging');
                    this.rePosDrag();
                    this.fixHeight();
                    this.colresize = false;
                } else if (this.vresize) {
                    this.vresize = false;
                } else if (this.colCopy) {
                    $(this.colCopy).remove();
                    if (this.dcolt != null) {
                        if (this.dcoln > this.dcolt) $('th:eq(' + this.dcolt + ')', this.hDiv).before(this.dcol);
                        else $('th:eq(' + this.dcolt + ')', this.hDiv).after(this.dcol);
                        this.switchCol(this.dcoln, this.dcolt);
                        $(this.cdropleft).remove();
                        $(this.cdropright).remove();
                        this.rePosDrag();
                        if (p.onDragCol) {
                            p.onDragCol(this.dcoln, this.dcolt);
                        }
                    }
                    this.dcol = null;
                    this.hset = null;
                    this.dcoln = null;
                    this.dcolt = null;
                    this.colCopy = null;
                    $('.thMove', this.hDiv).removeClass('thMove');
                    $(this.cDrag).show();
                }
                $('body').css('cursor', 'default');
                //$('body').noSelect(false);
            },
            toggleCol: function (cid, visible) {
                var ncol = $("th[axis='col" + cid + "']", this.hDiv)[0];
                var n = $('thead th', g.hDiv).index(ncol);
                var cb = $('input[value=' + cid + ']', g.nDiv)[0];
                if (visible == null) {
                    visible = ncol.hidden;
                }
                if ($('input:checked', g.nDiv).length < p.minColToggle && !visible) {
                    return false;
                }
                if (visible) {
                    ncol.hidden = false;
                    $(ncol).show();
                    cb.checked = true;
                } else {
                    ncol.hidden = true;
                    $(ncol).hide();
                    cb.checked = false;
                }
                $('tbody tr', t).each(
					function () {
					    if (visible) {
					        $('td:eq(' + n + ')', this).show();
					    } else {
					        $('td:eq(' + n + ')', this).hide();
					    }
					}
				);
                this.rePosDrag();
                if (p.onToggleCol) {
                    p.onToggleCol(cid, visible);
                }
                return visible;
            },
            switchCol: function (cdrag, cdrop) { //switch columns
                $('tbody tr', t).each(
					function () {
					    if (cdrag > cdrop) $('td:eq(' + cdrop + ')', this).before($('td:eq(' + cdrag + ')', this));
					    else $('td:eq(' + cdrop + ')', this).after($('td:eq(' + cdrag + ')', this));
					}
				);
                //switch order in nDiv
                if (cdrag > cdrop) {
                    $('tr:eq(' + cdrop + ')', this.nDiv).before($('tr:eq(' + cdrag + ')', this.nDiv));
                } else {
                    $('tr:eq(' + cdrop + ')', this.nDiv).after($('tr:eq(' + cdrag + ')', this.nDiv));
                }
                if ($.browser.msie && $.browser.version < 7.0) {
                    $('tr:eq(' + cdrop + ') input', this.nDiv)[0].checked = true;
                }
                this.hDiv.scrollLeft = this.bDiv.scrollLeft;
            },
            scroll: function () {
                this.hDiv.scrollLeft = this.bDiv.scrollLeft;
                this.rePosDrag();
            },
            addData: function (data) { //parse data
                if (p.dataType == 'json') {
                    data = $.extend({ rows: [], page: 0, total: 0 }, data);
                }
                if (p.preProcess) {
                    data = p.preProcess(data);
                }
                $('.pReload', this.pDiv).removeClass('loading');
                this.loading = false;
                if (!data) {
                    $('.pPageStat', this.pDiv).html(p.errormsg);
                    return false;
                }
                if (p.dataType == 'xml') {
                    p.total = +$('rows total', data).text();
                } else {
                    p.total = data.total;
                }
                if (p.total == 0) {
                    $('tr, a, td, div', t).unbind();
                    $(t).empty();
                    p.pages = 1;
                    p.page = 1;
                    this.buildpager();
                    $('.pPageStat', this.pDiv).html(p.nomsg);
                    return false;
                }
                p.pages = Math.ceil(p.total / p.rp);
                if (p.dataType == 'xml') {
                    p.page = +$('rows page', data).text();
                } else {
                    p.page = data.page;
                }
                this.buildpager();
                //build new body
                var tbody = document.createElement('tbody');

                //get this parent id as name space for command button's ids
                var idnmspc;
                if ($(t).attr("id")) {
                    idnmspc = $(t).attr("id");
                } else {
                    //generate random ids
                    idnmspc = Math.floor(Math.random() * 999999);
                };

                if (p.dataType == 'json') {
                    $.each(data.rows, function (i, row) {
                        var tr = document.createElement('tr');
                        if (i % 2 && p.striped) {
                            tr.className = 'erow';
                        };
                        if (row.id) {
                            tr.id = 'row' + row.id;
                        };

                        $('thead tr:first th', g.hDiv).each( //add cell
							function () {
							    var td = $('<td></td>');
							    var idx = $(this).attr('axis').substr(3);
							    var cellName = $(this).attr('data-name');
							    td.align = this.align;

							    var cellCtn = row.cell[idx];
							    var cmdStr;
							    var icon;
							    var tdCtn = (row.cell[idx] != null) ? row.cell[idx] : ''; //null-check for Opera-browser

							    // If the json elements aren't named (which is typical), use numeric order
							    if (typeof cellCtn != "undefined") {
							        if (cellName == 'command') {
							            if (typeof cellCtn == 'object') {
							                //build command buttons
							                for (var c = 0; c < p.commands.length; c++) {
							                    //create command btn
							                    var btnName = (i * p.commands.length) + c;
							                    var ibtn = $('<a href="#"></a>');
							                    if (p.commands[c].cssclass) {
							                        ibtn.addClass(p.commands[c].cssclass);
							                    } else {
							                        ibtn.css('margin', '0 2px');
							                    };
							                    var cmdBtn = $('<span></span>');
							                    cmdBtn.addClass('cmdbtn');
							                    if (p.commands[c].asLink == true) {
							                        //set as link
							                        ibtn.text(p.commands[c].title);
							                        cmdBtn.css({ width: 'auto', height: 'auto' });
							                    } else {
							                        ///set as button
							                        ibtn.attr("title", p.commands[c].title);
							                    };

							                    ibtn.attr("id", idnmspc + "_cmd" + btnName);
							                    ibtn.attr("data-name", p.commands[c].name);
							                    //hide button when false
							                    if (cellCtn[p.commands[c].name]) {
							                        ibtn.css('display', 'block');
							                    } else {
							                        ibtn.css('display', 'none');
							                    };
							                    cmdBtn.append(ibtn);
							                    td.append(cmdBtn);
							                };
							            } else {
							                td.html(tdCtn);
							            }
							        } else {
							            td.html(tdCtn);
							        };
							    } else {
							        if (cellName == 'command') {
							            if (typeof cellCtn == 'object') {
							                //build command buttons
							                for (var c = 0; c < p.commands.length; c++) {
							                    //create command btn
							                    var btnName = (i * p.commands.length) + c;
							                    var ibtn = $('<a href="#"></a>');
							                    if (p.commands[c].cssclass) {
							                        ibtn.addClass(p.commands[c].cssclass);
							                    } else {
							                        ibtn.css('margin', '0 2px');
							                    };
							                    var cmdBtn = $('<span></span>');
							                    cmdBtn.addClass('cmdbtn');
							                    if (p.commands[c].asLink == true) {
							                        //set as link
							                        ibtn.text(p.commands[c].title);
							                        cmdBtn.css({ width: 'auto', height: 'auto' });
							                    } else {
							                        ///set as button
							                        ibtn.attr("title", p.commands[c].title);
							                    };

							                    ibtn.attr("id", idnmspc + "_cmd" + btnName);
							                    ibtn.attr("data-name", p.commands[c].name);
							                    //hide button when false
							                    if (cellCtn[p.commands[c].name]) {
							                        ibtn.css('display', 'block');
							                    } else {
							                        ibtn.css('display', 'none');
							                    };
							                    cmdBtn.append(ibtn);
							                    td.append(cmdBtn);
							                };
							            } else {
							                td.html(row.cell[p.colModel[idx].name]);
							            };
							        } else {
							            td.html(row.cell[p.colModel[idx].name]);
							        };
							    };
							    $(td).attr('abbr', $(this).attr('abbr'));
							    $(tr).append(td);
							    td = null;
							}
						);
                        if ($('thead', this.gDiv).length < 1) {//handle if grid has no headers
                            for (idx = 0; idx < row.cell.length; idx++) {
                                var td = document.createElement('td');
                                // If the json elements aren't named (which is typical), use numeric order
                                if (typeof row.cell[idx] != "undefined") {
                                    td.innerHTML = (row.cell[idx] != null) ? row.cell[idx] : ''; //null-check for Opera-browser
                                } else {
                                    td.innerHTML = row.cell[p.colModel[idx].name];
                                };
                                $(tr).append(td);
                                td = null;
                            }
                        }
                        $(tbody).append(tr);
                        tr = null;
                    });
                } else if (p.dataType == 'xml') {
                    var i = 1;
                    $("rows row", data).each(function () {
                        i++;
                        var tr = document.createElement('tr');
                        if (i % 2 && p.striped) {
                            tr.className = 'erow';
                        }
                        var nid = $(this).attr('id');
                        if (nid) {
                            tr.id = 'row' + nid;
                        }
                        nid = null;
                        var robj = this;
                        $('thead tr:first th', g.hDiv).each(function () {
                            var td = document.createElement('td');
                            var idx = $(this).attr('axis').substr(3);
                            td.align = this.align;
                            td.innerHTML = $("cell:eq(" + idx + ")", robj).text();
                            $(td).attr('abbr', $(this).attr('abbr'));
                            $(tr).append(td);
                            td = null;
                        });
                        if ($('thead', this.gDiv).length < 1) {//handle if grid has no headers
                            $('cell', this).each(function () {
                                var td = document.createElement('td');
                                td.innerHTML = $(this).text();
                                $(tr).append(td);
                                td = null;
                            });
                        }
                        $(tbody).append(tr);
                        tr = null;
                        robj = null;
                    });
                }
                $('tr', t).unbind();
                $(t).empty();
                $(t).append(tbody);
                this.addCellProp(data);
                this.addRowProp();
                this.rePosDrag();
                tbody = null;
                data = null;
                i = null;
                if (p.onSuccess) {
                    p.onSuccess(this);
                }
                if (p.hideOnSubmit) {
                    $(g.block).remove();
                }
                this.hDiv.scrollLeft = this.bDiv.scrollLeft;
                if ($.browser.opera) {
                    $(t).css('visibility', 'visible');
                }
            },
            changeSort: function (th) { //change sortorder
                //disable sort for command column
                if ($(th).attr("abbr") == 'command') {
                    return true;
                } else {
                    if (this.loading) {
                        return true;
                    }
                    $(g.nDiv).hide();
                    $(g.nBtn).hide();
                    if (p.sortname == $(th).attr('abbr')) {
                        if (p.sortorder == 'asc') {
                            p.sortorder = 'desc';
                        } else {
                            p.sortorder = 'asc';
                        }
                    }
                    $(th).addClass('sorted').siblings().removeClass('sorted');
                    $('.sdesc', this.hDiv).removeClass('sdesc');
                    $('.sasc', this.hDiv).removeClass('sasc');
                    $('div', th).addClass('s' + p.sortorder);
                    p.sortname = $(th).attr('abbr');
                    if (p.onChangeSort) {
                        p.onChangeSort(p.sortname, p.sortorder);
                    } else {
                        this.populate();
                    };
                };
            },
            buildpager: function () { //rebuild pager based on new properties
                $('.pcontrol input', this.pDiv).val(p.page);
                $('.pcontrol span', this.pDiv).html(p.pages);
                var r1 = (p.page - 1) * p.rp + 1;
                var r2 = r1 + p.rp - 1;
                if (p.total < r2) {
                    r2 = p.total;
                }
                var stat = p.pagestat;
                stat = stat.replace(/{from}/, r1);
                stat = stat.replace(/{to}/, r2);
                stat = stat.replace(/{total}/, p.total);
                $('.pPageStat', this.pDiv).html(stat);
            },
            populate: function () { //get latest data
                if (this.loading) {
                    return true;
                }
                if (p.onSubmit) {
                    var gh = p.onSubmit();
                    if (!gh) {
                        return false;
                    }
                }
                this.loading = true;
                if (!p.url) {
                    return false;
                }
                $('.pPageStat', this.pDiv).html(p.procmsg);
                $('.pReload', this.pDiv).addClass('loading');
                $(g.block).css({
                    top: g.bDiv.offsetTop
                });
                if (p.hideOnSubmit) {
                    $(this.gDiv).prepend(g.block);
                }
                if ($.browser.opera) {
                    $(t).css('visibility', 'hidden');
                }
                if (!p.newp) {
                    p.newp = 1;
                }
                if (p.page > p.pages) {
                    p.page = p.pages;
                }
                var param = [{
                    name: 'page',
                    value: p.newp
                }, {
                    name: 'rp',
                    value: p.rp
                }, {
                    name: 'sortname',
                    value: p.sortname
                }, {
                    name: 'sortorder',
                    value: p.sortorder
                }, {
                    name: 'query',
                    value: p.query
                }, {
                    name: 'qtype',
                    value: p.qtype
                }];
                if (p.params) {
                    for (var pi = 0; pi < p.params.length; pi++) {
                        param[param.length] = p.params[pi];
                    }
                }
                $.ajax({
                    type: p.method,
                    url: p.url,
                    data: param,
                    dataType: p.dataType,
                    success: function (data) {
                        g.addData(data);
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        try {
                            if (p.onError) p.onError(XMLHttpRequest, textStatus, errorThrown);
                        } catch (e) { }
                    }
                });
            },
            doSearch: function () {
                p.query = $('input[name=q]', g.sDiv).val();
                p.qtype = $('select[name=qtype]', g.sDiv).val();
                p.newp = 1;
                this.populate();
            },
            changePage: function (ctype) { //change page
                if (this.loading) {
                    return true;
                }
                switch (ctype) {
                    case 'first':
                        p.newp = 1;
                        break;
                    case 'prev':
                        if (p.page > 1) {
                            p.newp = parseInt(p.page) - 1;
                        }
                        break;
                    case 'next':
                        if (p.page < p.pages) {
                            p.newp = parseInt(p.page) + 1;
                        }
                        break;
                    case 'last':
                        p.newp = p.pages;
                        break;
                    case 'input':
                        var nv = parseInt($('.pcontrol input', this.pDiv).val());
                        if (isNaN(nv)) {
                            nv = 1;
                        }
                        if (nv < 1) {
                            nv = 1;
                        } else if (nv > p.pages) {
                            nv = p.pages;
                        }
                        $('.pcontrol input', this.pDiv).val(nv);
                        p.newp = nv;
                        break;
                }
                if (p.newp == p.page) {
                    return false;
                }
                if (p.onChangePage) {
                    p.onChangePage(p.newp);
                } else {
                    this.populate();
                }
            },
            addCellProp: function (data) {
                $('tbody tr td', g.bDiv).each(function (idx) {
                    var tdDiv = $('<div></div>');
                    var n = $('td', $(this).parent()).index(this);
                    var pth = $('th:eq(' + n + ')', g.hDiv).get(0);

                    if (pth != null) {
                        if (p.sortname == $(pth).attr('abbr') && p.sortname) {
                            this.className = 'sorted';
                        };
                        $(tdDiv).css({
                            textAlign: pth.align,
                            width: $('div:first', pth)[0].style.width
                        });
                        if (pth.hidden) {
                            $(this).css('display', 'none');
                        };
                    };

                    if (p.nowrap == false) {
                        $(tdDiv).css('white-space', 'normal');
                    };
                    if (this.innerHTML == '') {
                        this.innerHTML = '&nbsp;';
                    };

                    var prnt = $(this).parent()[0];
                    var thisCell = $(this).html();
                    tdDiv.append(thisCell);

                    var pid = false;
                    if (prnt.id) {
                        pid = prnt.id.substr(3);
                    };

                    //if (pth != null) {
                    //    if (pth.process) pth.process(tdDiv, pid);
                    //}

                    $(this).empty().append(tdDiv).removeAttr('width'); //wrap content

                    var rId = 0;
                    if (typeof p.commands != 'undefined') {
                        rId = Math.floor(idx / p.commands.length);
                    };

                    $("span.cmdbtn a", tdDiv).click(function (e) {
                        $(this).closest('tr').addClass('trSelected');
                        if (p.singleSelect) $(this).closest('tr').siblings().removeClass('trSelected');
                        var _btnName = $(this).attr("id");
                        //create row's key-value object
                        var r = {};
                        if ($(this).closest('tr').attr('id').length) {
                            r['id'] = $(this).closest('tr').attr('id').substr(3);
                        };

                        for (var ti = 0; ti < $('div.hDivBox table tr', g.hDiv).children().length; ti++) {
                            var col = $('div.hDivBox table tr', g.hDiv).children().eq(ti);
                            var cell = $(this).closest('tr').children().eq(ti);
                            r[col.attr('data-name')] = cell.find('div').text();
                        };

                        var s = {};
                        s.name = $(this).attr("data-name");
                        s.id = _btnName;

                        for (var i = 0; i < p.commands.length; i++) {
                            if (p.commands[i].name == s.name) {
                                if (typeof p.commands[i].onpress === 'function') {
                                    p.commands[i].onpress(s, r, g.gDiv);
                                } else if (p.commands[i].onpress.toLowerCase() === 'flexilist') {
                                    if (p.flexilist) {
                                        g.flexiList.option = $.extend(g.flexiList.option, p.flexilist);
                                    };
                                    if (p.commands[i].idparam) {
                                        if (typeof p.commands[i].idparam === 'function') {
                                            //client flexilist dynamic setup from callback
                                            g.flexiList.open(p.commands[i].idparam(s, r, g.flexiList.flistobject));
                                        } else {
                                            //check if user uses 'id' or idcolum's value
                                            if (r.id.length && p.commands[i].idparam.toLowerCase() === 'id') {
                                                g.flexiList.open(r.id);
                                            } else {
                                                //pass id column value
                                                g.flexiList.open(r[p.commands[i].idparam]);
                                            };
                                        };
                                    };
                                } else if (p.commands[i].onpress.toLowerCase() === 'fleximodal') {
                                    if (p.fleximodal.onpress) {
                                        p.fleximodal.onpress(s, r, g.fleximodal.modal);
                                    };
                                } else if (p.commands[i].onpress.toLowerCase() === 'flexiform') {
                                    if (p.flexiform) {
                                        g.flexiform.option = $.extend(g.flexiform.option, p.flexiform);
                                    };

                                    g.flexiform.s = s;
                                    g.flexiform.r = r;
                                    g.flexiform.newForm = false;
                                    if (p.commands[i].onload) {
                                        p.commands[i].onload(s, r, g.flexiform.flexiformObject);
                                    } else {
                                        g.flexiform.open(s, r);
                                    };
                                };
                            };
                        };
                        e.preventDefault();
                        e.stopPropagation();
                    }).hover(function () {
                        if ($(this).attr('title')) {
                            // Hover over code                        
                            var title = $(this).attr('title');

                            $(this).data('tipText', title).removeAttr('title');
                            var tooltip = $('<p class="tooltip"></p>');
                            var offset = $(this).offset();
                            var posY = offset.top - $(window).scrollTop();
                            var posX = offset.left - $(window).scrollLeft();
                            tooltip
                            .text(title)
                            .appendTo('body')
                            .fadeIn('fast');
                            var tw = tooltip.outerWidth() / 2;
                            var th = tooltip.outerHeight();
                            tooltip
                            .css({
                                "top": (((posY - th) - 5) + $(window).scrollTop()) + "px",
                                "left": (((posX + 8) - tw) + $(window).scrollLeft()) + "px"
                            });
                        };

                    }, function () {
                        // Hover out code
                        if ($('.tooltip').length) {
                            $(this).attr('title', $(this).data('tipText'));
                            $('.tooltip').remove();
                        };
                    });
                });
                if (p.height == 'auto') {
                    g.fixHeight();
                };
                data = null;
            },
            getCellDim: function (obj) {// get cell prop for editable event
                var ht = parseInt($(obj).height());
                var pht = parseInt($(obj).parent().height());
                var wt = parseInt(obj.style.width);
                var pwt = parseInt($(obj).parent().width());
                var top = obj.offsetParent.offsetTop;
                var left = obj.offsetParent.offsetLeft;
                var pdl = parseInt($(obj).css('paddingLeft'));
                var pdt = parseInt($(obj).css('paddingTop'));
                return {
                    ht: ht,
                    wt: wt,
                    top: top,
                    left: left,
                    pdl: pdl,
                    pdt: pdt,
                    pht: pht,
                    pwt: pwt
                };
            },
            addRowProp: function () {
                $('tbody tr', g.bDiv).each(function () {
                    $(this).click(function (e) {
                        var obj = (e.target || e.srcElement);
                        if (obj.href || obj.type) return true;
                        $(this).toggleClass('trSelected');
                        if (p.singleSelect) $(this).siblings().removeClass('trSelected');
                    }).mousedown(function (e) {
                        if (e.shiftKey) {
                            $(this).toggleClass('trSelected');
                            g.multisel = true;
                            this.focus();
                            //$(g.gDiv).noSelect();
                        }
                    }).mouseup(function () {
                        if (g.multisel) {
                            g.multisel = false;
                            //$(g.gDiv).noSelect(false);
                        }
                    }).hover(function (e) {
                        if (g.multisel) {
                            $(this).toggleClass('trSelected');
                        }
                    }, function () { });
                    if ($.browser.msie && $.browser.version < 7.0) {
                        $(this).hover(function () {
                            $(this).addClass('trOver');
                        }, function () {
                            $(this).removeClass('trOver');
                        });
                    }
                });
            },
            flexiList: {
                option: { //dynamic settings
                    title: '',
                    url: p.flexilist.url,
                    width: p.flexilist.width,
                    height: 'auto', //should be auto or # pixels
                    pagestat: "Page {current} of {total} Pages.",
                    procmsg: p.procmsg,
                    params: null,
                    errormsg: 'Connection error',
                    dataType: p.dataType,
                    rp: 5,
                    opacity: 0.5,
                    bgcolor: "#000",
                    pages: 0,  //total pages
                    cpage: 1,  //current page
                    npage: 1,  //new page
                    total: 0,   //totalitems
                    nomsg: p.nomsg,
                    striped: p.striped
                },
                flistobject: {
                    id: function (num) {
                        g.flexiList.id = num;
                    },
                    title: function (strtitle) {
                        g.flexiList.option.title = strtitle;
                    },
                    width: function (strW) {
                        g.flexiList.option.width = strW;
                    },
                    height: function (strH) {
                        g.flexiList.option.height = strH;
                    },
                    url: function (addr) {
                        g.flexiList.option.url = addr;
                    },
                    params: function (prm) {
                        g.flexiList.option.params = prm;
                    },
                    setStatus: function (strstatus) {
                        g.flexiList.option.pagestat = strstatus;
                        alert(strstatus);
                        g.flexiList.pStatus.text(status);
                    },
                    hideRow: function (s) {
                        var $btn = $('#' + s.id);
                        if ($btn.length) {
                            $('.tooltip').remove();
                            $btn.closest('tr').removeClass('trSelected').addClass('trHighlight').fadeOut(800, function () {
                                $(this).hide();
                            });
                        };
                    },
                    reload: function () {
                        g.flexiList.populate();
                    },
                    setLoading: function (bolstatus) {
                        if (bolstatus) {
                            $("div.pReload", g.flexiList.pdiv).addClass('loading');
                        } else {
                            $("div.pReload", g.flexiList.pdiv).removeClass('loading');
                        };
                    }
                },
                id: null,
                open: function (id) {
                    var option = { //default settings
                        url: p.flexilist.url,
                        dataType: p.flexilist.dataType,
                        rp: p.flexilist.rp,
                        width: '300px',
                        height: 'auto', //should be auto or # pixels
                        opacity: p.blockOpacity,
                        bgcolor: "#000",
                        pages: 0,  //total pages
                        cpage: 1,  //current page
                        npage: 1,  //new page
                        total: 0,   //totalitems
                        pagestat: "Page {current} of {total} Pages.",
                        procmsg: p.procmsg,
                        nomsg: p.nomsg,
                        errormsg: p.errormsg,
                        striped: p.striped
                    };

                    if (id) {
                        g.flexiList.id = id;
                    };

                    if (!g.flexiList.id) {
                        //no id is set
                        return false;
                    };

                    option = g.flexiList.option;
                    var fl = g.flexiList.fList.empty();

                    //title
                    var hdiv = $('<div class="mDiv"></div>').appendTo(fl);
                    if (option.title) {
                        var title = g.flexiList.title;
                        title.text(option.title).appendTo(hdiv);
                    } else {
                        hdiv.append('<div style="height:11px;">&nbsp;</div>');
                    };

                    var closeDiv = $('<div class="ptogtitle"></div>')
                    closeDiv.addClass('close').appendTo(hdiv);
                    var close = g.flexiList.closebtn.appendTo(closeDiv);
                    close.click(function () {
                        g.flexiList.close();
                    });

                    //headers
                    var hdiv = $('<div class="hDiv"></div>');
                    var hdiv2 = $('<div class="hDivBox"></div>');
                    hdiv.append(hdiv2);
                    var ht = $('<table></table>');
                    ht.attr({ "cellspacing": "0", "cellpadding": "0" });
                    hdiv2.append(ht);
                    var htHead = $('<thead></thead>');
                    var htTr = $("<tr/>");
                    ht.append(htHead);
                    htHead.append(htTr);
                    for (var i = 0; i < option.colModel.length; i++) {
                        var colM = option.colModel[i];
                        var htTh = $("<th/>");
                        var thDiv = $('<div/>');

                        if (colM.name) {
                            htTh.attr("abbr", colM.name);
                        };

                        if (colM.align) {
                            htTh.attr("align", colM.align);
                            thDiv.css("text-align", colM.align);
                        };

                        if (colM.hide) {
                            htTh.hide();
                        };

                        if (colM.display) {
                            thDiv.text(colM.display);
                        };

                        if (colM.width) {
                            thDiv.css("width", parseInt(colM.width) + "px");
                        };

                        htTh.append(thDiv);
                        htTr.append(htTh);
                    };
                    fl.append(hdiv);

                    //list body
                    var bdiv = g.flexiList.bdiv.empty().appendTo(fl);
                    bdiv.css("height", "auto");
                    $(bdiv).scroll(function () {
                        $(hdiv).scrollLeft($(bdiv).scrollLeft());
                    });

                    //list navigation
                    var pdiv = g.flexiList.pdiv.empty().appendTo(fl);
                    var pdiv2 = $('<div class="pDiv2"></div>').appendTo(pdiv);
                    //reload button
                    var pg = $('<div class="pGroup"></div>').appendTo(pdiv2);
                    var reloadBtn = g.flexiList.reloadbtn.appendTo(pg);
                    var pgsep = $('<div class="btnseparator"></div>').appendTo(pdiv2);
                    reloadBtn.click(function () {
                        g.flexiList.populate();
                    });

                    //pager
                    var pg2 = $('<div class="pGroup"></div>').appendTo(pdiv2);
                    var firstBtn = g.flexiList.firstbtn.appendTo(pg2);
                    var prevBtn = g.flexiList.prevbtn.appendTo(pg2);
                    var pgsep2 = $('<div class="btnseparator"></div>').appendTo(pdiv2);

                    //pager page number wrapper
                    var pg3 = $('<div class="pGroup"></div>').appendTo(pdiv2);
                    var nc1 = $('<div class="pCon"></div>').appendTo(pg3);
                    var n1 = g.flexiList.n1.appendTo(nc1);
                    var nc2 = $('<div class="pCon"></div>').appendTo(pg3);
                    var n2 = g.flexiList.n2.appendTo(nc2).hide();
                    var nc3 = $('<div class="pCon"></div>').appendTo(pg3);
                    var n3 = g.flexiList.n3.appendTo(nc3).hide();
                    var nc4 = $('<div class="pCon"></div>').appendTo(pg3);
                    var n4 = g.flexiList.n4.appendTo(nc4).hide();
                    var nc5 = $('<div class="pCon"></div>').appendTo(pg3);
                    var n5 = g.flexiList.n5.appendTo(nc5).hide();
                    var pgsep3 = $('<div class="btnseparator"></div>').appendTo(pdiv2);

                    //pager
                    var pg4 = $('<div class="pGroup"></div>').appendTo(pdiv2);
                    var nextBtn = g.flexiList.nextbtn.appendTo(pg4);
                    var lastBtn = g.flexiList.lastbtn.appendTo(pg4);
                    var pgsep4 = $('<div class="btnseparator"></div>').appendTo(pdiv2);

                    //page status
                    var pg5 = $('<div class="pGroup"></div>').appendTo(pdiv2);
                    var ps = g.flexiList.pStatus.empty().appendTo(pg5);

                    $("div.pBtn", pg3).click(function () {
                        $(this).addClass('selected').parent().siblings().find("div.pNum").removeClass('selected');
                        g.flexiList.pageChange($(this).find('span').text());
                    });

                    firstBtn.click(function () {
                        g.flexiList.pageChange('first');
                    });

                    prevBtn.click(function () {
                        g.flexiList.pageChange('prev');
                    });

                    nextBtn.click(function () {
                        g.flexiList.pageChange('next');
                    });

                    lastBtn.click(function () {
                        g.flexiList.pageChange('last');
                    });

                    $('body').append(g.fleximodal.overlay, g.fleximodal.container);
                    g.fleximodal.overlay.show().fadeTo(option.opacity).css("background", option.bgcolor);
                    g.fleximodal.container.append(fl).show();
                    g.fleximodal.container.width(option.width); //this height is set by option
                    if (option.height.toLowerCase() === 'auto') {
                        if ($('table', bdiv).width() < parseInt(option.width)) {
                            g.fleximodal.container.height(23 + 25 + (option.rp * 28) + 1 + 31);
                            bdiv.height(option.rp * 28);
                        } else {
                            //16 for slider bar
                            g.fleximodal.container.height(23 + 25 + (option.rp * 28) + 1 + 31 + 16);
                            bdiv.height((option.rp * 28) + 16);
                        };
                    } else {
                        g.fleximodal.container.height(option.height);
                    };
                    g.fleximodal.center();

                    g.flexiList.populate();
                },
                close: function () {
                    //reset settings to default
                    var option = g.flexiList.option;
                    if (p.flexilist.title) {
                        option.title = p.flexilist.title;
                    } else {
                        option.title = '';
                    };
                    if (p.flexilist.url) {
                        option.url = p.flexilist.url;
                    };
                    if (p.flexilist.width) {
                        option.width = p.flexilist.width;
                    };
                    option.height = 'auto';
                    option.pagestat = "Page {current} of {total} Pages.";
                    option.procmsg = p.procmsg;
                    if (p.flexilist.params) {
                        option.params = p.flexilist.params;
                    };
                    option.pages = 0;
                    option.cpage = 1;
                    option.npage = 1;
                    option.total = 0;
                    g.flexiList.id = null;
                    g.flexiList.closebtn.unbind();
                    g.flexiList.reloadbtn.unbind();
                    g.flexiList.firstbtn.unbind();
                    g.flexiList.prevbtn.unbind();
                    g.flexiList.nextbtn.unbind();
                    g.flexiList.lastbtn.unbind();
                    $('div.pBtn', g.flexiList.pdiv).unbind();
                    g.flexiList.title.empty();
                    $('div, span, a, tr, td', g.fleximodal.container).unbind();
                    g.flexiList.pStatus.empty();
                    g.flexiList.bdiv.empty();
                    g.flexiList.pdiv.empty();
                    g.flexiList.fList.empty();
                    g.fleximodal.container.empty().hide().remove();
                    g.fleximodal.overlay.hide().remove();
                },
                buildlist: function (data) {
                    var opt = g.flexiList.option;
                    if (data.error == true || data.error == "true") {
                        $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                        g.flexiList.pStatus.text(opt.errormsg);
                    } else {
                        if (data.message) {
                            var rd = data.message; //return datas
                            if (rd.count == 0) {
                                opt.pages = 1;
                                opt.cpage = 1;
                                opt.total = 0;
                                //empty pages
                                g.flexiList.pStatus.text(opt.nomsg);
                            } else {
                                opt.total = rd.total;
                                opt.pages = Math.ceil(rd.total / opt.rp);
                                if (opt.pages <= 0) {
                                    opt.pages = 1;
                                };

                                opt.cpage = rd.page;
                                //pagestat                                                                                   
                                var stat = opt.pagestat;
                                stat = stat.replace(/{current}/, opt.cpage);
                                stat = stat.replace(/{total}/, opt.pages);
                                g.flexiList.pStatus.text(stat).css("color", "#000");

                                if (opt.cpage <= 0) {
                                    opt.cpage = 1;
                                };

                                //build page numeric navigation                                   
                                var sNum = Math.floor((opt.cpage - 1) / 5);
                                var mNum = sNum * 5;
                                var n1 = g.flexiList.n1;
                                n1.find('span').text(mNum + 1);
                                if ((mNum + 1) == opt.cpage) {
                                    n1.addClass("selected").show();
                                } else {
                                    n1.removeClass("selected");
                                };

                                var n2 = g.flexiList.n2;
                                n2.find('span').text(mNum + 2);
                                if ((mNum + 2) == opt.cpage) {
                                    n2.addClass("selected").show();
                                } else {
                                    if ((mNum + 2) > opt.pages) {
                                        n2.hide().removeClass("selected");
                                    } else {
                                        n2.show().removeClass("selected");
                                    };
                                };

                                var n3 = g.flexiList.n3;
                                n3.find('span').text(mNum + 3);
                                if ((mNum + 3) == opt.cpage) {
                                    n3.addClass("selected").show();
                                } else {
                                    if ((mNum + 3) > opt.pages) {
                                        n3.hide().removeClass("selected");
                                    } else {
                                        n3.show().removeClass("selected");
                                    };
                                };

                                var n4 = g.flexiList.n4;
                                n4.find('span').text(mNum + 4);
                                if ((mNum + 4) == opt.cpage) {
                                    n4.addClass("selected").show();
                                } else {
                                    if ((mNum + 4) > opt.pages) {
                                        n4.hide().removeClass("selected");
                                    } else {
                                        n4.show().removeClass("selected");
                                    };
                                };

                                var n5 = g.flexiList.n5;
                                n5.find("span").text(mNum + 5);
                                if ((mNum + 5) == opt.cpage) {
                                    n5.addClass("selected").show();
                                } else {
                                    if ((mNum + 5) > opt.pages) {
                                        n5.hide().removeClass("selected");
                                    } else {
                                        n5.show().removeClass("selected");
                                    };
                                };
                                //get id namespace for command button's ids
                                var flidnm;
                                if ($(t).attr("id")) {
                                    flidnm = $(t).attr("id");
                                } else {
                                    flidnm = Math.floor(Math.random() * 9999);
                                };

                                //create list table                                                                
                                var tlist = $('<table class="autoht" cellspacing="0" cellpadding="0" border="0"></table>');
                                var tblist = $('<tbody />').appendTo(tlist);
                                $.each(rd.rows, function (i, row) {
                                    var trlist = $('<tr/>').appendTo(tblist);
                                    if (i % 2 && opt.striped) {
                                        trlist.addClass('erow');
                                    };

                                    //create row object
                                    var r = {};
                                    for (ro = 0; ro < opt.colModel.length; ro++) {
                                        if (opt.colModel[ro].name != 'command' || typeof row.cell[ro] != 'object') {
                                            r[opt.colModel[ro].name] = row.cell[ro];
                                        };
                                    };
                                    for (var c = 0; c < opt.colModel.length; c++) {
                                        var col = opt.colModel[c];
                                        var tdlist = $('<td/>').appendTo(trlist);
                                        tdlist.attr("abbr", col.name);
                                        if (col.hide) {
                                            tdlist.hide();
                                        };
                                        var tdivlist = $('<div/>').appendTo(tdlist);
                                        if (col.name == 'command') {
                                            tdivlist.css({
                                                "width": col.width + "px",
                                                "text-align": "center"
                                            });
                                            //build command btns                                        
                                            if (typeof row.cell[c] == 'object') {
                                                for (var ci = 0; ci < opt.buttons.length; ci++) {
                                                    var cd = opt.buttons[ci];
                                                    var cmdid = ((opt.cpage - 1) * opt.rp) + (i * opt.buttons.length) + ci;
                                                    var cmdspan = $('<span/>').appendTo(tdivlist);
                                                    cmdspan.addClass("cmdbtn");
                                                    var cmda = $('<a href="#"></a>').appendTo(cmdspan);
                                                    cmda.addClass(cd.cssclass);
                                                    cmda.attr("id", flidnm + "_flcmd" + cmdid)
                                                    cmda.attr("title", cd.title);
                                                    var s =
                                                        {
                                                            name: cd.name,
                                                            id: flidnm + "_flcmd" + cmdid
                                                        };
                                                    cmda.click(function (e) {
                                                        e.preventDefault();
                                                        e.stopPropagation();
                                                        var $this = $(this);
                                                        $this.closest('tr').addClass('trSelected').siblings().removeClass('trSelected');
                                                        $("div.pReload", g.flexiList.pdiv).addClass("loading");
                                                        var prevpagerstat = g.flexiList.pStatus.text();
                                                        g.flexiList.pStatus.text(opt.procmsg).css("color", "#000");
                                                        $.when(cd.onpress(s, r, g.flexiList.flistobject)).done(function (args) {
                                                            if (args.error == true || args.error == 'true') {
                                                                $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                                                                g.flexiList.pStatus.text(opt.errormsg).css("color", "red");
                                                            } else {
                                                                $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                                                                g.flexiList.pStatus.text(prevpagerstat).css("color", "#000");
                                                            };
                                                            args = null;
                                                        });
                                                    }).hover(function () {
                                                        // tooltip code
                                                        var yoffset = 10;
                                                        var title = $(this).attr('title');
                                                        var offset = $(this).offset();
                                                        var posY = offset.top - $(window).scrollTop();
                                                        var posX = offset.left - $(window).scrollLeft();
                                                        $(this).data('tipText', title).removeAttr('title');
                                                        var tooltip = $('<p class="tooltip"></p>');
                                                        tooltip
                                                        .text(title)
                                                        .appendTo('body')
                                                        .fadeIn('slow')
                                                        .css("z-index", "12000");
                                                        var tw = tooltip.outerWidth() / 2;
                                                        var th = tooltip.outerHeight();
                                                        tooltip.css({
                                                            "top": (((posY - th) - 5) + $(window).scrollTop()) + "px",
                                                            "left": (((posX + 8) - tw) + $(window).scrollLeft()) + "px"
                                                        });
                                                    }, function () {
                                                        // Hover out code
                                                        $(this).attr('title', $(this).data('tipText'));
                                                        $('.tooltip').remove();
                                                    });
                                                };
                                            };
                                        } else {
                                            tdivlist.css({
                                                "width": col.width + "px",
                                                "text-align": col.align
                                            }).text(row.cell[c]);
                                        };
                                    };
                                });

                                $('tr, td, div, span, a', g.flexiList.bdiv).unbind();
                                g.flexiList.bdiv.empty();
                                tlist.appendTo(g.flexiList.bdiv);
                                $('<div style="width:100%;height:1px;background:#ccc;"></div>').appendTo(g.flexiList.bdiv);
                            };
                        };
                    };
                    data = null;
                    $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                },
                populate: function () {
                    var opt = g.flexiList.option;
                    if ($("div.pReload", g.flexiList.pdiv).hasClass("loading")) {
                        return true;
                    };

                    $("div.pReload", g.flexiList.pdiv).addClass("loading");
                    g.flexiList.pStatus.text(opt.procmsg);

                    if (opt.npage == 0) {
                        opt.npage = 1;
                    };

                    var _params = [{
                        name: 'page',
                        value: opt.npage
                    }, {
                        name: 'rp',
                        value: opt.rp
                    }, {
                        name: 'id',
                        value: g.flexiList.id
                    }];

                    //_params = $.extend(_params, opt.params);
                    if (opt.params) {
                        for (var pi = 0; pi < opt.params.length; pi++) {
                            _params[_params.length] = opt.params[pi];
                        };
                    };

                    if (!opt.url) {
                        return false;
                    };

                    if (!opt.npage) {
                        opt.npage = 1;
                    };

                    if (opt.npage > opt.pages) {
                        opt.npage = opt.pages;
                    };

                    var req = $.ajax({
                        type: 'POST',
                        url: opt.url,
                        data: _params,
                        dataType: opt.dataType
                    });
                    req.done(function (data) {
                        if (data.error == "true" || data.error == true) {
                            $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                            g.flexiList.pStatus.text(data.message).css("color", "red");
                        } else {
                            g.flexiList.buildlist(data);
                        };
                        data = null;
                    });
                    req.fail(function () {
                        $("div.pReload", g.flexiList.pdiv).removeClass("loading");
                        g.flexiList.pStatus.text(opt.errormsg).css("color", "red");
                    });
                },
                pageChange: function (ctype) {
                    var opt = g.flexiList.option;
                    if ($('div.pReload', g.flexiList.pdiv).hasClass("loading")) {
                        return true;
                    };

                    switch (ctype) {
                        case 'first':
                            opt.npage = 1;
                            break;
                        case 'prev':
                            if (opt.cpage > 1) {
                                opt.npage = opt.cpage - 1;
                            };
                            break;
                        case 'next':
                            if (opt.cpage < opt.pages) {
                                opt.npage = opt.cpage + 1;
                            }
                            break;
                        case 'last':
                            opt.npage = opt.pages;
                            break;
                        default:
                            if (isNaN(ctype)) {
                                opt.npage = 1;
                            };
                            if (ctype < 1) {
                                opt.npage = 1;
                            } else if (ctype > opt.pages) {
                                opt.npage = opt.pages;
                            } else {
                                opt.npage = parseInt(ctype);
                                if (opt.npage == 0 || isNaN(opt.npage)) {
                                    opt.npage = 1;
                                };
                            };
                            break;
                    };
                    if (opt.npage == opt.cpage) {
                        return false;
                    };
                    g.flexiList.populate();
                },
                fList: $('<div class="flexigrid"></div>'),
                closebtn: $('<span></span>'),
                title: $('<div class="ftitle"></div>'),
                bdiv: $('<div class="bDiv"></div>'),
                pdiv: $('<div class="pDiv"></div>'),
                reloadbtn: $('<div class="pReload pButton"><span></span></div>'),
                firstbtn: $('<div class="pFirst pButton"><span></span></div>'),
                prevbtn: $('<div class="pPrev pButton"><span></span></div>'),
                nextbtn: $('<div class="pNext pButton"><span></span></div>'),
                lastbtn: $('<div class="pLast pButton"><span></span></div>'),
                n1: $('<div class="pNum pBtn"><span>1</span></div>'),
                n2: $('<div class="pNum pBtn"><span>2</span></div>'),
                n3: $('<div class="pNum pBtn"><span>3</span></div>'),
                n4: $('<div class="pNum pBtn"><span>4</span></div>'),
                n5: $('<div class="pNum pBtn"><span>5</span></div>'),
                pStatus: $('<span class="pPageStat"></span>')
            },
            fleximodal: {
                option: {}, //to store session settings
                modal: {
                    setContent: function (ctn) {
                        $('a, span, div, td, tr', g.fleximodal.body).unbind();
                        g.fleximodal.body.empty().append(ctn);
                    },
                    open: function (settings) {
                        g.fleximodal.open(settings);
                    },
                    close: function () {
                        g.fleximodal.close();
                    },
                    loading: function (bolLoading) {
                        if (bolLoading) {
                            g.fleximodal.reloadButton.addClass('loading').css('cursor', 'default').show();
                            g.fleximodal.mstatus.text(g.fleximodal.option.procmsg);
                        } else {
                            g.fleximodal.reloadButton.removeClass('loading').css('cursor', 'pointer').toggle(g.fleximodal.option.reloadButton.use);
                            g.fleximodal.mstatus.empty();
                        };
                    },
                    setStatus: function (strStatus) {
                        g.fleximodal.mstatus.text(strStatus).show();
                    },
                    clearStatus: function () {
                        g.fleximodal.mstatus.empty().hide();
                    },
                    hideOkButton: function () {
                        g.fleximodal.okButton.hide();
                    },
                    setOkButton: function (oktxt) {
                        g.fleximodal.okButton.find('span').text(oktxt);
                    },
                    hideCancelButton: function () {
                        g.fleximodal.cancelButton.hide();
                    },
                    setCancelButton: function (canceltxt) {
                        g.fleximodal.cancelButton.find('span').text(canceltxt);
                    },
                    toggleReload: function () {
                        if (arguments.length == 1) {
                            g.fleximodal.reloadButton.toggle(arguments[0]);
                        } else {
                            g.fleximodal.reloadButton.toggle();
                        };
                    }
                },
                center: function () {
                    g.fleximodal.container.css({
                        "top": (($(window).height() - g.fleximodal.container.outerHeight()) / 2), // + $(window).scrollTop(),
                        "left": (($(window).width() - g.fleximodal.container.outerWidth()) / 2) // + $(window).scrollLeft()
                    })
                },
                open: function (s) {
                    var option = { // default settings
                        width: '350',
                        height: '200',
                        opacity: 0.5,
                        bgcolor: "#000",
                        showHeader: true,
                        title: false,
                        showFooter: true,
                        okButton: { use: false, display: 'OK', class: '', onpress: '' },
                        cancelButton: { use: false, display: 'Cancel', class: '', onpress: '' },
                        reloadButton: { use: false, onpress: '' },
                        content: ''
                    };

                    option = $.extend(option, p.fleximodal, s);
                    //option = $.extend(option, s);                    

                    g.fleximodal.option = option;
                    //setup fleximodal dimension
                    var mheight = parseInt(option.height);
                    if (option.showHeader) {
                        if (option.showFooter) {
                            mheight = mheight + 54;
                        } else {
                            mheight = mheight + 23;
                        };
                    } else {
                        if (option.showFooter) {
                            mheight = mheight + 31;
                        };
                    };

                    var modal = g.fleximodal;
                    $('div, span, a, tr, td', modal.container).unbind();
                    modal.container.empty();
                    modal.container.width(parseInt(option.width) + 2).height(mheight);
                    $('body').append(modal.overlay, modal.container);
                    modal.overlay.fadeTo('fast', option.opacity).css("background", option.bgcolor);
                    modal.container.fadeIn('fast');

                    //modal ui
                    var mcon = $('<div class="flexigrid"></div>').width(parseInt(option.width) + 2).height(mheight).appendTo(modal.container);
                    if (option.showHeader) {
                        var hdiv = $('<div class="mDiv"></div>').appendTo(mcon);
                        if (option.title == false || option.title == '') {
                            hdiv.append('<div style="height:11px;">&nbsp;</div>');
                        } else {
                            var title = $('<div class="ftitle"></div>');
                            title.text(option.title).appendTo(hdiv);
                        };

                        var closeDiv = $('<div class="ptogtitle"></div>')
                        closeDiv.addClass('close').appendTo(hdiv);
                        var close = $('<span></span>').appendTo(closeDiv);
                        close.click(function () {
                            g.fleximodal.close();
                        });
                    };

                    var mbodyheight = parseInt(option.height);
                    var mbody = g.fleximodal.body.css('border', '1px solid #eee').height(mbodyheight).appendTo(mcon);
                    if (option.content != '') {
                        $('div, span, a tr, td', mbody).unbind();
                        mbody.empty().append(option.content);
                    };

                    //footer ui 
                    if (option.showFooter) {
                        var fcon = $('<div class="pDiv"></div>').height(30).appendTo(mcon);
                        var fcon2 = $('<div class="pDiv2"></div>').css({ "float": "left", "width": "100%" }).appendTo(fcon);
                        var okbtn = g.fleximodal.okButton.unbind().empty();
                        var cancelbtn = g.fleximodal.cancelButton.unbind().empty();
                        var reloadbtn = g.fleximodal.reloadButton.unbind();
                        //setup reload button
                        var pg = $('<div class="pGroup"></div>').width(20).appendTo(fcon2);
                        reloadbtn.appendTo(pg);
                        if (!option.reloadButton.use) {
                            reloadbtn.hide().css('cursor', 'default');
                        };
                        $('<div class="btnseparator" ></div>').appendTo(fcon2);
                        if (typeof option.reloadButton.onpress === 'function') {
                            reloadbtn.unbind().click(function () {
                                if (option.reloadButton.param) {
                                    option.reloadButton.onpress(g.fleximodal.modal, option.reloadButton.param);
                                } else {
                                    option.reloadButton.onpress(g.fleximodal.modal);
                                };
                            });
                        };

                        //modal status
                        var pspg = $('<div class="pGroup"></div>').empty().appendTo(fcon2);
                        g.fleximodal.mstatus.appendTo(pspg);

                        //cancel button
                        var cpg = $('<div class="pGroup"></div>').css('float', 'right').appendTo(fcon2);
                        var cdiv2 = $('<div></div>').appendTo(cancelbtn);
                        var cspan = $('<span></span>').appendTo(cdiv2);
                        cspan.css("padding-left", "20px").text(option.cancelButton.display);
                        if (option.cancelButton.class) {
                            cspan.addClass(option.cancelButton.class);
                        } else {
                            cspan.addClass('cancelbtn');
                        };
                        cancelbtn.click(function () {
                            if (typeof option.cancelButton.onpress === 'function') {
                                if (option.cancelButton.param) {
                                    option.cancelButton.onpress(g.fleximodal.modal, option.cancelButton.param);
                                } else {
                                    option.cancelButton.onpress(g.fleximodal.modal);
                                };
                            } else {
                                g.fleximodal.close();
                            };
                        });
                        cancelbtn.appendTo(cpg);
                        if (option.cancelButton.use) {
                            cancelbtn.show();
                        } else {
                            cancelbtn.hide();
                        };

                        //setup ok button
                        if (option.cancelButton.use) {
                            $('<div class="btnseparator"></div>').css('float', 'right').appendTo(fcon2);
                        };
                        var okpg = $('<div class="pGroup"></div>').css('float', 'right').appendTo(fcon2);
                        var okdiv2 = $('<div></div>').appendTo(okbtn);
                        var okspan = $('<span></span>').appendTo(okdiv2);
                        okspan.css("padding-left", "20px").text(option.okButton.display);
                        if (option.okButton.class) {
                            okspan.addClass(option.okButton.class)
                        } else {
                            okspan.addClass('okbtn');
                        };

                        okbtn.click(function () {
                            if (typeof option.okButton.onpress === 'function') {
                                if (option.okButton.param) {
                                    option.okButton.onpress(g.fleximodal.modal, option.okButton.param);
                                } else {
                                    option.okButton.onpress(g.fleximodal.modal);
                                };
                            };
                        });
                        okbtn.appendTo(okpg);
                        if (option.okButton.use) {
                            okbtn.show();
                        } else {
                            okbtn.hide();
                        };
                    };
                    $(window).bind('center.modal', g.fleximodal.center());
                },
                close: function () {
                    $(window).unbind('center.modal');
                    if (g.fleximodal.option.okButton.use) {
                        g.fleximodal.okButton.unbind();
                        g.fleximodal.okButton.empty();
                    };
                    if (g.fleximodal.option.cancelButton.use) {
                        g.fleximodal.cancelButton.unbind();
                        g.fleximodal.cancelButton.empty();
                    };
                    if (g.fleximodal.option.reloadButton.use) {
                        g.fleximodal.reloadButton.unbind();
                        g.fleximodal.reloadButton.empty();
                    };
                    $('div, span, a, tr, td, ul, li', g.fleximodal.container).unbind();
                    g.fleximodal.container.hide().empty().remove();
                    g.fleximodal.overlay.hide().remove();
                },
                reloadButton: $('<div class="pReload pButton"></div>'),
                okButton: $('<div class="fbutton"></div>'),
                cancelButton: $('<div class="fbutton"></div>'),
                overlay: $('<div class="fleximodalbg"></div>'),
                container: $('<div class="fleximodalcon"></div>'),
                body: $('<div class="bDiv"></div>'),
                mstatus: $('<span class="pPageStat"></span>')
            },
            flexiform: {
                s: null,
                r: null,
                newForm: true, //mode = true for editing, false for new empty form
                completed: false,
                formObject: null,
                option: {
                    url: p.url,
                    dataType: 'json',
                    title: '',
                    description: '',
                    width: '350px',
                    height: 'auto',
                    params: null,
                    procmsg: p.procmsg,
                    errormsg: p.errormsg,
                    requiredText: '(Required)',
                    submitButton: { use: true, display: 'Submit', cssClass: 'savebtn' },
                    resetButton: { use: false, display: 'Reset', cssClass: 'resetbtn' },
                    formFields: null,
                    striped: p.striped,
                    showLegend: true,
                    opacity: 0.5,
                    bgcolor:"#000",
                    selectorText: 'Select from list below',
                    multiSelectText: '{item} of {items} selected',
                    onSubmit: {
                        close: true,
                        highlight: true,
                        updateRow: true,
                        action: null
                    }
                },
                flexiformObject: {
                    s: function (objS) {
                        g.flexiform.s = objS;
                    },
                    r: function (objR) {
                        g.flexiform.r = objR;
                    },
                    setUrl: function (strUrl) {
                        g.flexiform.option.url = strUrl;
                    },
                    setTitle: function (strtitle) {
                        g.flexiform.option.title = strtitle;
                    },
                    setDescription: function (strdesc) {
                        g.flexiform.option.description = strdesc;
                    },
                    setWidth: function (strW) {
                        g.flexiform.option.width = parseInt(strW);
                    },
                    setHeight: function (strH) {
                        g.flexiform.option.height = parseInt(strH);
                    },
                    params: function (prm) {
                        //overrides params
                        g.flexiform.option.params = prm;
                    },
                    open: function () {
                        if (arguments.length == 2) {
                            g.flexiform.open(arguments[0], arguments[1]);
                        } else {
                            g.flexiform.open();
                        };
                    },
                    reset: function () {
                        g.flexiform.reset();
                    },
                    submit: function () {
                        g.flexiform.submit();
                    },
                    close: function () {
                        g.flexiform.close();
                    }
                },
                open: function (s, r) {
                    var option = g.flexiform.option;
                    g.flexiform.completed = false; //set flag indicating finished processing form
                    if (g.flexiform.newForm) {
                        g.flexiform.s = null;
                        g.flexiform.r = null;
                    } else {
                        if (s && r) {
                            g.flexiform.s = s;
                            g.flexiform.r = r;
                        };
                        if (!g.flexiform.s || !g.flexiform.r) {
                            return false;
                        };
                    };

                    if (!g.flexiform.option.formFields.length) {
                        return false;
                    };

                    var foheight = 0;
                    var bolreq = false;

                    //create empty form object
                    var fo = {};
                    var ffid;
                    if ($(t).attr("id")) {
                        ffid = $(t).attr("id") + '__';
                    } else {
                        ffid = Math.floor(Math.random() * 9999) + '__';
                    };

                    var modalbg = g.fleximodal.overlay.fadeTo(option.opacity).css("background", option.bgcolor).hide();
                    var modal = g.fleximodal.container.hide();
                    var conDiv = $('<div class="flexigrid"></div>').appendTo(modal);

                    //create titlebar
                    var mDiv = $('<div class="mDiv"></div>').appendTo(conDiv);
                    if (option.title == false || option.title == '') {
                        $('<div style="height:11px;">&nbsp;</div>').appendTo(mDiv);
                    } else {
                        var title = $('<div class="ftitle"></div>');
                        title.text(option.title).appendTo(mDiv);
                    };
                    var closeDiv = $('<div class="ptogtitle"></div>')
                    closeDiv.addClass('close').appendTo(mDiv);
                    var close = $('<span></span>').appendTo(closeDiv);
                    close.click(function () {
                        g.flexiform.close();
                    });

                    var bDiv = $('<div class="bDiv"></div>').appendTo(conDiv);
                    //description and error summaries container
                    if (option.description.length) {
                        var edDiv = $('<div class="frow"></div>').appendTo(bDiv);
                        edDiv.css({ 'min-height': '30px', 'max-height': '60px', "overflow": "visible" });
                        var edlbl = $('<div/>').appendTo(edDiv);
                        edlbl.css({ "margin": "5px 10px", "color": "#444" }).html(option.description);

                        foheight += 31;
                        fo['message'] = edlbl;
                    };

                    //required legend
                    var reqDiv = $('<div class="frow"></div>').appendTo(bDiv);
                    reqDiv.css("margin", "5px 0").hide();
                    var reqDiv2 = $('<div class="lgd"></div>').appendTo(reqDiv);
                    reqDiv2.addClass('reqIco');
                    var reqlbl = $('<span/>').appendTo(reqDiv2);
                    reqlbl.text(option.requiredText);

                    //setup forms element
                    for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                        var cf = g.flexiform.option.formFields[i];
                        switch (cf.formType.toLowerCase()) {
                            case 'hidden':
                                var objEl = {};
                                var h = $('<input type="hidden"/>');
                                h.attr('name', ffid + cf.name);
                                if (!g.flexiform.newForm) {
                                    if (cf.value) {
                                        h.val(cf.value);
                                        objEl['default'] = cf.valueOf;
                                    } else {
                                        h.val(g.flexiform.r[cf.name]);
                                        objEl['default'] = g.flexiform.r[cf.name];
                                    };
                                };
                                objEl['formElement'] = h;
                                objEl['error'] = false;

                                fo[cf.name] = objEl;
                                h.appendTo(bDiv);
                                break;
                            case 'textbox':
                                var objEl = {};
                                var tb = $('<input type="text"/>');
                                tb.attr('name', ffid + cf.name);
                                if (g.flexiform.newForm) {
                                    if (cf.value) {
                                        tb.val(cf.value);
                                        objEl['default'] = cf.value;
                                    };
                                } else {
                                    if (cf.value) {
                                        tb.val(cf.value);
                                        objEl['default'] = cf.value;
                                    } else {
                                        if (g.flexiform.r[cf.name]) {
                                            tb.val(g.flexiform.r[cf.name]);
                                            objEl['default'] = g.flexiform.r[cf.name];
                                        };
                                    };
                                };
                                if (cf.align) {
                                    tb.css('text-align', cf.align);
                                } else {
                                    tb.css('text-align', 'left');
                                };
                                objEl['formElement'] = tb
                                objEl['error'] = false;
                                foheight += 69;

                                var fc = $('<div class="frow"></div>').appendTo(bDiv);
                                if (i % 2 && option.striped) {
                                    fc.css('background-color', '#f7f7f7');
                                };

                                var tcon = $('<div class="fLbl"></div>').appendTo(fc);
                                var tlbl = $('<span></span>').appendTo(tcon);
                                tlbl.text(cf.display);
                                objEl['displayText'] = tlbl;

                                var elcon = $('<div class="formEl"></div>').appendTo(fc);
                                var el = $('<div class="eltb"></div>').appendTo(elcon);
                                tb.appendTo(el);

                                var valIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var valspan = $('<span></span>').appendTo(valIcon);
                                objEl['validationIcon'] = valIcon;

                                var reqIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var reqSpan = $('<span></span>').appendTo(reqIcon);
                                if (cf.required) {
                                    reqIcon.addClass('required');
                                    bolreq = true;
                                };

                                var errDiv = $('<div class="err"></div>').appendTo(fc);
                                errlbl = $('<span></span>').appendTo(errDiv);
                                if (cf.validationMessage) {
                                    errlbl.html(cf.validationMessage);
                                    objEl['defaultMessage'] = cf.validationMessage;
                                } else {
                                    objEl['defaultMessage'] = '';
                                };
                                errlbl.hide();

                                objEl['validationMessage'] = errlbl;
                                objEl['validation'] = cf.validation;
                                objEl['required'] = cf.required;
                                fo[cf.name] = objEl;

                                //validation 
                                if (cf.validation) {
                                    objEl['validation'] = cf.validation;
                                    tb.change(function () {
                                        var el = {};
                                        var thisname = $(this).attr('name');
                                        el['name'] = thisname.substring(thisname.indexOf('__') + 2);
                                        el['value'] = $(this).val();

                                        var fObj = g.flexiform.formObject[el.name];
                                        el['display'] = fObj.displayText.text();

                                        var errObj = {};
                                        errObj['setMessage'] = function (strMsg) {
                                            fObj.validationMessage.text(strMsg);
                                        };
                                        errObj['setDefaultMessage'] = function () {
                                            if (fObj.defaultMessage) {
                                                fObj.validationMessage.text(fObj.defaultMessage);
                                            } else {
                                                fObj.validationMessage.text('');
                                            };
                                        };
                                        if (fObj.validation(el, errObj)) {
                                            //error
                                            fObj.error = true;
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            fObj.validationMessage.show();
                                            $(this).parent().css('border', '1px solid red');
                                        } else {
                                            fObj.error = false;
                                            fObj.validationIcon.removeClass('error').addClass('check');
                                            fObj.validationMessage.hide();
                                            $(this).parent().css('border', '1px solid #DDD');
                                        };
                                    });
                                } else if (cf.required) {
                                    tb.change(function () {
                                        var elname = $(this).attr('name');
                                        elname = elname.substring(elname.indexOf('__') + 2);
                                        var objFo = g.flexiform.formObject[elname];
                                        if (objFo.formElement.val() && objFo.formElement.val().trim() !== '') {
                                            //no error 
                                            objFo.error = false;
                                            objFo.validationIcon.removeClass('error').addClass('check');
                                            objFo.validationMessage.hide();
                                            objFo.formElement.parent().css('border', '1px solid #DDD');
                                        } else {
                                            //error 
                                            objFo.error = true;
                                            if (objFo.defaultMessage) {
                                                objFo.validationMessage.text(objFo.defaultMessage).show();
                                            };
                                            objFo.validationIcon.removeClass('check').addClass('error');
                                            objFo.formElement.parent().css('border', '1px solid red');
                                        };
                                    });
                                };
                                break;
                            case 'textarea':
                                var objEl = {};
                                var ta = $('<textarea></textarea>');
                                ta.attr('name', ffid + cf.name);
                                if (!g.flexiform.newForm) {
                                    if (cf.value) {
                                        ta.val(cf.value);
                                        objEl['default'] = cf.value;
                                    } else {
                                        if (g.flexiform.r[cf.name]) {
                                            ta.val(g.flexiform.r[cf.name]);
                                            objEl['default'] = g.flexiform.r[cf.name];
                                        };
                                    };
                                };

                                objEl['formElement'] = ta;
                                objEl['error'] = false;

                                fo[cf.name] = objEl;
                                foheight += 98;

                                var fc = $('<div class="frow"></div>').appendTo(bDiv);
                                if (i % 2 && option.striped) {
                                    fc.css('background-color', '#f7f7f7');
                                };

                                var flblcon = $('<div class="fLbl">').appendTo(fc);
                                var flbl = $('<span/>').appendTo(flblcon);
                                flbl.text(cf.display);
                                objEl['displayText'] = flbl;

                                var elcon = $('<div class="formEl"></div>').appendTo(fc);
                                elcon.height(59);
                                var el = $('<div class="elta"></div>').appendTo(elcon);
                                el.append(ta);
                                var valIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var valspan = $('<span></span>').appendTo(valIcon);
                                objEl['validationIcon'] = valIcon;

                                var reqIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var reqSpan = $('<span></span>').appendTo(reqIcon);
                                if (cf.required) {
                                    reqIcon.addClass('required');
                                    bolreq = true;
                                };

                                var clearDiv = $('<div style="clear:both"></div>').appendTo(elcon);

                                var err = $('<div class="err"></div>').appendTo(fc);
                                var errlbl = $('<span></span>').appendTo(err);
                                if (cf.validationMessage) {
                                    errlbl.html(cf.validationMessage);
                                    objEl['defaultMessage'] = cf.validationMessage;
                                } else {
                                    objEl['defaultMessage'] = '';
                                };
                                errlbl.hide();
                                objEl['validationMessage'] = errlbl;
                                objEl['validation'] = cf.validation;
                                objEl['required'] = cf.required;

                                if (cf.validation) {
                                    objEl['validation'] = cf.validation;
                                    var valfnta = cf.validation;
                                    var eltaname = cf.name;
                                    var eltadisplay = cf.display;
                                    ta.change(function () {
                                        var el = {};
                                        var thisname = $(this).attr('name');
                                        el['name'] = thisname.substring(thisname.indexOf('__') + 2);
                                        el['value'] = $(this).val();

                                        var fObj = g.flexiform.formObject[eltaname];
                                        el['display'] = fObj.displayText.text();

                                        var errObj = {};
                                        errObj['setMessage'] = function (strMsg) {
                                            fObj.validationMessage.text(strMsg);
                                        };
                                        errObj['setDefaultMessage'] = function () {
                                            if (fObj.defaultMessage) {
                                                fObj.validationMessage.text(fObj.defaultMessage);
                                            } else {
                                                fObj.validationMessage.text('');
                                            };
                                        };

                                        if (fObj.validation(el, errObj)) {
                                            //error
                                            fObj.error = true;
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            fObj.validationMessage.show();
                                            $(this).parent().css('border', '1px solid red');
                                        } else {
                                            fObj.error = false;
                                            fObj.validationIcon.removeClass('error').addClass('check');
                                            fObj.validationMessage.hide();
                                            $(this).parent().css('border', '1px solid #DDD');
                                        };
                                    });
                                } else if (cf.required) {
                                    ta.change(function () {
                                        var elname = $(this).attr('name');
                                        elname = elname.substring(elname.indexOf('__') + 2);
                                        var objFo = g.flexiform.formObject[elname];
                                        if (objFo.formElement.val() && objFo.formElement.val().trim() !== '') {
                                            //no error 
                                            fObj.error = false;
                                            objFo.validationMessage.hide();
                                            objFo.validationIcon.removeClass('error').addClass('check');
                                            objFo.formElement.parent().css('border', '1px solid #DDD');
                                        } else {
                                            //error 
                                            fObj.error = true;
                                            if (objFo.defaultMessage) {
                                                objFo.validationMessage.text(objFo.defaultMessage).show();
                                            };
                                            objFo.validationIcon.removeClass('check').addClass('error');
                                            objFo.formElement.parent().css('border', '1px solid red');
                                        };
                                    });
                                };
                                break;
                            case 'selector':
                                var objEl = {};
                                var ul = $('<ul></ul>');
                                ul.attr('data-name', ffid + cf.name);
                                for (var ie = 0; ie < cf.options.length; ie++) {
                                    var li = $('<li></li>');
                                    var litxt = $('<div></div>').appendTo(li);
                                    litxt.text(cf.options[ie].text);
                                    if (cf.options[ie].value) {
                                        li.attr('data-value', cf.options[ie].value);
                                    };
                                    if (cf.options[ie].selected === true) {
                                        li.addClass('liSelected');
                                    };
                                    li.appendTo(ul);
                                };
                                //objEl['default'] = null; //not needed
                                objEl['formElement'] = ul;
                                objEl['error'] = false;
                                fo[cf.name] = objEl;
                                foheight += 69;

                                var fc = $('<div class="frow"></div>').appendTo(bDiv);
                                if (i % 2 && option.striped) {
                                    fc.css('background-color', '#f7f7f7');
                                };

                                var flblcon = $('<div class="fLbl"></div>').appendTo(fc);
                                var flbl = $('<span></span').appendTo(flblcon);
                                flbl.text(cf.display);

                                var elcon = $('<div class="formEl"></div>').appendTo(fc);
                                var elsel = $('<div class="eltb"></div>').appendTo(elcon);
                                var sellbl = $('<div class="sellbl"></div>').appendTo(elsel);
                                objEl['displayText'] = sellbl;
                                if (cf.singleSelect) {
                                    var selValue = ul.find('li.liSelected').text();
                                    if (selValue.length) {
                                        sellbl.text(selValue);
                                    } else {
                                        sellbl.text(g.flexiform.option.selectorText);
                                    };
                                } else {
                                    var mtxt = g.flexiform.option.multiSelectText;
                                    mtxt = mtxt.replace(/{item}/, ul.find('li.liSelected').length);
                                    mtxt = mtxt.replace(/{items}/, ul.children().length);
                                    sellbl.text(mtxt);
                                };

                                var selddn = $('<span class="ddn"></span>').appendTo(elsel);
                                elsel.click(function () {
                                    var objUl = $(this).closest('div.formEl').children().last().find('ul');
                                    objUl.slideToggle('fast');
                                    $(this).parent().find('span').toggleClass('ddn uup');
                                });

                                var valIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var valspan = $('<span></span>').appendTo(valIcon);
                                objEl['validationIcon'] = valIcon;

                                var reqIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var reqSpan = $('<span></span>').appendTo(reqIcon);
                                if (cf.required) {
                                    reqIcon.addClass('required');
                                    bolreq = true;
                                };

                                var clearDiv = $('<div style="clear:both"></div>').appendTo(elcon);
                                var ulcon = $('<div></div>').appendTo(elcon);
                                ulcon.css("position", "relative");
                                ulcon.append(ul);
                                ul.css({
                                    top: ulcon.css('top'),
                                    left: ulcon.css('left')
                                });

                                var err = $('<div class="err"></div>').appendTo(fc);
                                var errlbl = $('<span></span>').appendTo(err);
                                if (cf.validationMessage) {
                                    errlbl.text(cf.validationMessage);
                                    objEl['defaultMessage'] = cf.validationMessage;
                                } else {
                                    objEl['defaultMessage'] = '';
                                };
                                errlbl.hide();
                                objEl['validationMessage'] = errlbl;
                                objEl['validation'] = cf.validation;

                                objEl['singleSelect'] = cf.singleSelect;
                                objEl['required'] = cf.required;

                                ul.children().each(function () {
                                    $(this).click(function () {
                                        var elname = $(this).closest('ul').attr('data-name');
                                        elname = elname.substring(elname.indexOf('__') + 2);
                                        var objFo = g.flexiform.formObject[elname];

                                        if ($(this).hasClass('liSelected')) {
                                            $(this).removeClass('liSelected');
                                        } else {
                                            $(this).addClass('liSelected');
                                            if (objFo.singleSelect === true) {
                                                $(this).siblings().removeClass('liSelected');
                                            };
                                        };
                                        if (objFo.singleSelect !== true) {
                                            var mtxt = g.flexiform.option.multiSelectText;
                                            mtxt = mtxt.replace(/{item}/, ul.find('li.liSelected').length);
                                            mtxt = mtxt.replace(/{items}/, ul.children().length);
                                            sellbl.text(mtxt);
                                        } else {
                                            sellbl.text($(this).find('div').text());
                                            $(this).parent().toggle(false);
                                        };

                                        var counttSelected = $(this).closest('ul').find('li.liSelected').length;
                                        if (!counttSelected) {
                                            objFo.displayText.text('');
                                        } else {
                                            objFo.displayText.text($(this).find('div').text());
                                        };

                                        if (objFo.validation) {
                                            //use client validation
                                            var el = {};
                                            el['name'] = elname;
                                            var objval = [];
                                            var objU = $(this).closest('ul');
                                            objU.children().each(function (i) {
                                                var objOption = {};
                                                objOption['value'] = $(this).attr('data-value');
                                                objOption['text'] = $(this).find('div').text();
                                                objOption['selected'] = $(this).hasClass('liSelected');
                                                objval[i] = objOption;
                                            });
                                            el['value'] = objval;

                                            var errObj = {};
                                            errObj['setMessage'] = function (strMsg) {
                                                objFo.validationMessage.text(strMsg);
                                            };
                                            errObj['setDefaultMessage'] = function () {
                                                if (objFo.defaultMessage) {
                                                    objFo.validationMessage.text(objFo.defaultMessage);
                                                } else {
                                                    objFo.validationMessage.text('');
                                                };
                                            };
                                            if (objFo.validation(el, errObj)) {
                                                objFo.formElement.toggle(false);
                                                objFo.error = true;
                                                objFo.validationMessage.show();
                                                objFo.validationIcon.removeClass('check').addClass('error');
                                                objFo.displayText.parent().css('border', '1px solid red');
                                            } else {
                                                objFo.error = false;
                                                objFo.validationMessage.hide();
                                                objFo.validationIcon.removeClass('error').addClass('check');
                                                objFo.displayText.parent().css('border', '1px solid #DDD');
                                            };
                                        } else if (objFo.required) {
                                            if (!counttSelected) {
                                                objFo.formElement.toggle(false);
                                                objFo.error = true;
                                                if (objFo.defaultMessage) {
                                                    objFo.validationMessage.text(objFo.defaultMessage).show();
                                                };
                                                objFo.validationIcon.removeClass('check').addClass('error');
                                                objFo.displayText.parent().css('border', '1px solid red');
                                            } else {
                                                objFo.error = false;
                                                objFo.validationMessage.hide();
                                                objFo.validationIcon.removeClass('error').addClass('check');
                                                objFo.displayText.parent().css('border', '1px solid #DDD');
                                            };
                                        };
                                    });
                                });
                                break;
                            default:
                                var objEl = {};
                                var tb = $('<input type="text"/>');
                                tb.attr('name', ffid + cf.name);
                                if (g.flexiform.newForm) {
                                    if (cf.value) {
                                        tb.val(cf.value);
                                        objEl['default'] = cf.value;
                                    };
                                } else {
                                    if (cf.value) {
                                        tb.val(cf.value);
                                        objEl['default'] = cf.value;
                                    } else {
                                        if (g.flexiform.r[cf.name]) {
                                            tb.val(g.flexiform.r[cf.name]);
                                            objEl['default'] = g.flexiform.r[cf.name];
                                        };
                                    };
                                };
                                if (cf.align) {
                                    tb.css('text-align', cf.align);
                                } else {
                                    tb.css('text-align', 'left');
                                };
                                objEl['formElement'] = tb
                                objEl['error'] = false;
                                foheight += 69;

                                var fc = $('<div class="frow"></div>').appendTo(bDiv);
                                if (i % 2 && option.striped) {
                                    fc.css('background-color', '#f7f7f7');
                                };

                                var tcon = $('<div class="fLbl"></div>').appendTo(fc);
                                var tlbl = $('<span></span>').appendTo(tcon);
                                tlbl.text(cf.display);
                                objEl['displayText'] = tlbl;

                                var elcon = $('<div class="formEl"></div>').appendTo(fc);
                                var el = $('<div class="eltb"></div>').appendTo(elcon);
                                tb.appendTo(el);

                                var valIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var valspan = $('<span></span>').appendTo(valIcon);
                                objEl['validationIcon'] = valIcon;

                                var reqIcon = $('<div class="ico"></div>').appendTo(elcon);
                                var reqSpan = $('<span></span>').appendTo(reqIcon);
                                if (cf.required) {
                                    reqIcon.addClass('required');
                                    bolreq = true;
                                };

                                var errDiv = $('<div class="err"></div>').appendTo(fc);
                                errlbl = $('<span></span>').appendTo(errDiv);
                                if (cf.validationMessage) {
                                    errlbl.html(cf.validationMessage);
                                    objEl['defaultMessage'] = cf.validationMessage;
                                } else {
                                    objEl['defaultMessage'] = '';
                                };
                                errlbl.hide();

                                objEl['validationMessage'] = errlbl;
                                objEl['validation'] = cf.validation;
                                objEl['required'] = cf.required;
                                fo[cf.name] = objEl;

                                //validation 
                                if (cf.validation) {
                                    objEl['validation'] = cf.validation;
                                    tb.change(function () {
                                        var el = {};
                                        var thisname = $(this).attr('name');
                                        el['name'] = thisname.substring(thisname.indexOf('__') + 2);
                                        el['value'] = $(this).val();

                                        var fObj = g.flexiform.formObject[el.name];
                                        el['display'] = fObj.displayText.text();

                                        var errObj = {};
                                        errObj['setMessage'] = function (strMsg) {
                                            fObj.validationMessage.text(strMsg);
                                        };
                                        errObj['setDefaultMessage'] = function () {
                                            if (fObj.defaultMessage) {
                                                fObj.validationMessage.text(fObj.defaultMessage);
                                            } else {
                                                fObj.validationMessage.text('');
                                            };
                                        };
                                        if (fObj.validation(el, errObj)) {
                                            //error
                                            fObj.error = true;
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            fObj.validationMessage.show();
                                            $(this).parent().css('border', '1px solid red');
                                        } else {
                                            fObj.error = false;
                                            fObj.validationIcon.removeClass('error').addClass('check');
                                            fObj.validationMessage.hide();
                                            $(this).parent().css('border', '1px solid #DDD');
                                        };
                                    });
                                } else if (cf.required) {
                                    ta.change(function () {
                                        var elname = $(this).attr('name');
                                        elname = elname.substring(elname.indexOf('__') + 2);
                                        var objFo = g.flexiform.formObject[elname];
                                        if (objFo.formElement.val() && objFo.formElement.val().trim() !== '') {
                                            //no error 
                                            objFo.error = true;
                                            objFo.validationIcon.removeClass('error').addClass('check');
                                            objFo.validationMessage.hide();
                                            objFo.formElement.parent().css('border', '1px solid #DDD');
                                        } else {
                                            //error 
                                            objFo.error = false;
                                            objFo.validationIcon.removeClass('check').addClass('error');
                                            if (objFo.defaultMessage) {
                                                objFo.validationMessage.text(objFo.defaultMessage).show();
                                            };
                                            objFo.formElement.parent().css('border', '1px solid red');
                                        };
                                    });
                                };
                                break;
                        };
                    };

                    //footer                    
                    var fcon = $('<div class="pDiv"></div>').height(30).appendTo(conDiv);
                    var fcon2 = $('<div class="pDiv2"></div>').css({ "float": "left", "width": "100%" }).appendTo(fcon);

                    //setup reload button
                    var pg = $('<div class="pGroup"></div>').width(20).appendTo(fcon2);
                    var loadIcon = $('<div class="pReload pButton loading"></div>').appendTo(pg);
                    loadIcon.css('cursor', 'default').hide();
                    fo['loadingIcon'] = loadIcon;
                    $('<div class="btnseparator" ></div>').appendTo(fcon2);

                    //modal status
                    var pspg = $('<div class="pGroup"></div>').empty().appendTo(fcon2);
                    var formstatus = $('<span class="pPageStat"></span>').appendTo(pspg);
                    fo['formStatus'] = formstatus;

                    //submit button
                    var submitbtn = $('<div class="fbutton"></div>');
                    var submitpg = $('<div class="pGroup"></div>').css('float', 'right').appendTo(fcon2);
                    var submitdiv2 = $('<div></div>').appendTo(submitbtn);
                    var submitspan = $('<span></span>').appendTo(submitdiv2);

                    submitspan.css("padding-left", "20px").text(option.submitButton.display);
                    if (option.submitButton.cssClass) {
                        submitspan.addClass(option.submitButton.cssClass)
                    } else {
                        submitspan.addClass('savebtn');
                    };

                    submitbtn.click(function () {
                        g.flexiform.submit();
                    });
                    submitbtn.appendTo(submitpg);
                    if (option.submitButton.use) {
                        submitbtn.show();
                    } else {
                        submitbtn.hide();
                    };

                    //cancel button
                    if (option.submitButton.use) {
                        $('<div class="btnseparator"></div>').css('float', 'right').appendTo(fcon2);
                    };
                    var cpg = $('<div class="pGroup"></div>').css('float', 'right').appendTo(fcon2);
                    var resetbtn = $('<div class="fbutton"></div>');
                    var cdiv2 = $('<div></div>').appendTo(resetbtn);
                    var cspan = $('<span></span>').appendTo(cdiv2);
                    cspan.css("padding-left", "20px").text(option.resetButton.display);
                    if (option.resetButton.cssClass) {
                        cspan.addClass(option.resetButton.cssClass);
                    } else {
                        cspan.addClass('resetbtn');
                    };
                    resetbtn.click(function () {
                        g.flexiform.reset();
                    });
                    resetbtn.appendTo(cpg);
                    if (option.resetButton.use) {
                        resetbtn.show();
                    } else {
                        resetbtn.hide();
                    };

                    if (bolreq && option.showLegend) {
                        reqDiv.show();
                        foheight += 35;
                    };
                    //add additonal height
                    var fDiv = $('<div/>').appendTo(bDiv);
                    fDiv.css({ 'height': '40px', 'border-top': '1px solid #DDD' });
                    foheight += 41;

                    bDiv.height(foheight);
                    //title bar and footer
                    foheight += (23 + 31);

                    g.flexiform.formObject = fo;
                    $('body').append(modalbg);
                    $('body').append(modal);
                    if (option.height == "auto") {
                        conDiv.height(foheight);
                    } else {
                        conDiv.height(parseInt(option.height))
                    };

                    modalbg.show();
                    modal.height(foheight).show();
                    conDiv.width(parseInt(option.width));
                    modal.width(parseInt(option.width));

                    //centering
                    var top = ($(window).height() - modal.outerHeight()) / 2;
                    if (top < 0) {
                        top = 0;
                    };
                    modal.css({
                        'left': (($(window).width() - modal.outerWidth()) / 2) + 'px',
                        'top': top + 'px'
                    });
                },
                close: function () {
                    //reset flexiform
                    g.flexiform.s = null;
                    g.flexiform.r = null;
                    g.flexiform.completed = false; //reset flag                   
                    g.flexiform.newForm = true;
                    //for each formobject must be unbind
                    for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                        var cf = g.flexiform.option.formFields[i];
                        if (cf.formType.toLowerCase() !== 'hidden') {
                            if (cf.formType.toLowerCase() === 'selector') {
                                g.flexiform.formObject[cf.name].displayText.parent().unbind();
                                g.flexiform.formObject[cf.name].formElement.children().each(function () {
                                    $(this).unbind();
                                });
                            } else {
                                g.flexiform.formObject[cf.name].formElement.unbind('change');
                            };
                        };
                    };
                    g.flexiform.formObject = null;
                    $('div, span, a, tr, td, li', g.fleximodal.container).unbind();
                    g.fleximodal.overlay.hide().remove();
                    g.fleximodal.container.hide().empty().remove();
                },
                reset: function () {
                    var fo = g.flexiform.formObject;
                    for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                        var cf = g.flexiform.option.formFields[i];
                        if (cf.formType.toLowerCase() === 'selector') {
                            var lis = fo[cf.name].formElement.children();
                            fo[cf.name].formElement.find('li').removeClass('liSelected');
                            for (var ie = 0; ie < cf.options.length; ie++) {
                                if (cf.options[ie].selected === true) {
                                    lis.eq(ie).addClass('liSelected');
                                    fo[cf.name].displayText.text(cf.options[ie].text);
                                };
                            };
                            if (fo[cf.name].defaultMessage) {
                                fo[cf.name].validationMessage.text(fo[cf.name].defaultMessage);
                            };
                            fo[cf.name].validationMessage.hide();
                            fo[cf.name].validationIcon.removeClass('check error');
                            fo[cf.name].displayText.parent().css('border', '1px solid #DDD');
                            fo[cf.name].error = false;
                        } else {
                            if (fo[cf.name]['default']) {
                                fo[cf.name].formElement.val(fo[cf.name]['default']);
                            } else {
                                fo[cf.name].formElement.val('');
                            };
                            if (cf.formType.toLowerCase() !== 'hidden') {
                                //reset validation if any
                                fo[cf.name].validationIcon.removeClass('check error');
                                if (fo[cf.name].defaultMessage) {
                                    fo[cf.name].validationMessage.text(fo[cf.name].defaultMessage);
                                };
                                fo[cf.name].validationMessage.hide();
                                fo[cf.name].formElement.parent().css('border', '1px solid #DDD');
                            };
                            fo[cf.name].error = false;
                        };
                    };
                },
                submit: function () {
                    var bolError = false;
                    var formParams = []; //create empty form element object
                    //check validations
                    for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                        var cf = g.flexiform.option.formFields[i];
                        fObj = g.flexiform.formObject[cf.name];
                        var formEl = {};
                        formEl['name'] = cf.name;
                        if (fObj.error) {
                            bolError = true;
                        } else {
                            //check for error

                            //create error object
                            var errObj = {};
                            errObj['setMessage'] = function (strMsg) {
                                fObj.validationMessage.text(strMsg);
                            };
                            errObj['setDefaultMessage'] = function () {
                                if (fObj.defaultMessage) {
                                    fObj.validationMessage.text(fObj.defaultMessage);
                                } else {
                                    fObj.validationMessage.text('');
                                };
                            };
                            //check form field types
                            if (cf.formType.toLowerCase() === 'hidden') {
                                formEl['value'] = fObj.formElement.val();
                            } else {
                                if (cf.formType.toLowerCase() === 'selector') {
                                    var el = {};
                                    el['name'] = cf.name;
                                    var objVal = [];
                                    var countSelected = 0;
                                    var paramVal = '';
                                    //var paramSel = '';
                                    fObj.formElement.children().each(function (i) {
                                        var objOption = {};
                                        objOption['text'] = $(this).find('div').text();
                                        objOption['value'] = $(this).attr('data-value');
                                        if ($(this).hasClass('liSelected')) {
                                            countSelected += 1;
                                            objOption['selected'] = true;
                                            if (!paramVal) {
                                                paramVal = $(this).attr('data-value');
                                            } else {
                                                paramVal = paramVal + ',' + $(this).attr('data-value');
                                            };
                                        } else {
                                            objOption['selected'] = false;
                                        };
                                        objVal[i] = objOption;
                                    });
                                    el['value'] = objVal;
                                    formEl['value'] = paramVal;
                                    if (cf.validation) {
                                        if (cf.validation(el, errObj)) {
                                            bolError = true;
                                            fObj.displayText.parent().css('border', '1px solid red');
                                            fObj.validationIcon.removeClass('check');
                                            fObj.validationMessage.show();
                                        };
                                        //no need to check if validation result = false
                                    } else if (cf.required) {
                                        if (countSelected === 0) {
                                            bolError = true;
                                            fObj.displayText.parent().css('border', '1px solid red')
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            if (fObj.defaultMessage) {
                                                fObj.validationMessage.text(fObj.defaultMessage).show();
                                            };
                                        };
                                    };
                                } else {
                                    var el = {};
                                    el['name'] = cf.name;
                                    el['value'] = fObj.formElement.val();
                                    formEl['value'] = fObj.formElement.val();
                                    if (cf.validation) {
                                        if (cf.validation(el, errObj)) {
                                            bolError = true;
                                            fObj.formElement.parent().css('border', '1px solid red');
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            fObj.validationMessage.show();
                                        };
                                    } else if (cf.required) {
                                        if (!fObj.formElement.val()) {
                                            bolError = true;
                                            fObj.formElement.parent().css('border', '1px solid red');
                                            fObj.validationIcon.removeClass('check').addClass('error');
                                            if (fObj.defaultMessage) {
                                                fObj.validationMessage.text(fObj.defaultMessage).show();
                                            };
                                        };
                                    };
                                };
                            };
                        };

                        formParams[i] = formEl;
                    };

                    if (!bolError) {
                        //no error, submit form
                        if (g.flexiform.option.params) {
                            for (var ie = 0; ie < g.flexiform.option.params.length; ie++) {
                                formParams[formParams.length] = g.flexiform.option.params[ie];
                            };
                        };

                        var fo = g.flexiform.formObject;
                        fo.loadingIcon.show()
                        fo.formStatus.text(g.flexiform.option.procmsg);
                        fo.formStatus.css('color', '#000');

                        var req = $.ajax({
                            type: 'POST',
                            url: g.flexiform.option.url,
                            data: formParams,
                            dataType: g.flexiform.option.dataType
                        });
                        req.done(function (data) {
                            if (data.error == true || data.error == 'true') {
                                //error                              
                                if (data.message != '') {
                                    fo.loadingIcon.hide();
                                    fo.formStatus.css('color', 'red').text(data.message);
                                };
                                if (!$.isEmptyObject(data.formObject)) {
                                    //get formobject send from server
                                    var sfo = data.formObject;
                                    for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                                        var ff = g.flexiform.option.formFields[i];
                                        if (sfo[ff.name].error == true || sfo[ff.name].error == 'true') {
                                            if (ff.formType !== 'hidden') {
                                                fo[ff.name].validationIcon.removeClass('check').addClass('error');
                                                if (!$.isEmptyObject(sfo[ff.name].message)) {
                                                    fo[ff.name].validationMessage.text(sfo[ff.name].message).show();
                                                };

                                                if (ff.formType.toLowerCase() == 'selector') {
                                                    fo[ff.name].displayText.parent().css('border', '1px solid red');
                                                } else {
                                                    fo[ff.name].formElement.parent().css('border', '1px solid red');
                                                };
                                            };
                                        } else {
                                            if (ff.formType !== 'hidden') {
                                                fo[ff.name].validationIcon.removeClass('error').addClass('check');
                                                fo[ff.name].validationMessage.hide();
                                                if (ff.formType.toLowerCase() == 'selector') {
                                                    fo[ff.name].displayText.parent().css('border', '1px solid #DDD');
                                                } else {
                                                    fo[ff.name].formElement.parent().css('border', '1px solid #DDD');
                                                };
                                            };
                                        };
                                    };
                                };
                            } else if (data.error == false || data.error == 'false') {
                                fo.formStatus.css('color', '#000');
                                if (!g.flexiform.newForm) {
                                    var btnid = g.flexiform.s.id;
                                    //hightlight row 
                                    if (g.flexiform.option.onSubmit.highlight) {
                                        $('#' + btnid).closest('tr').removeClass('trSelected').addClass('trHighlight');
                                    };

                                    setTimeout(function () {
                                        if (g.flexiform.option.onSubmit.highlight) {
                                            $('#' + btnid).closest('tr').removeClass('trHighlight').addClass('trSelected');
                                        };

                                        //update data to grid object
                                        for (var i = 0; i < g.flexiform.option.formFields.length; i++) {
                                            var ff = g.flexiform.option.formFields[i];
                                            if (ff.formType !== 'hidden') {
                                                //updating row content
                                                if (g.flexiform.option.onSubmit.updateRow) {
                                                    $('th', g.hDiv).each(function (ie) {
                                                        if (ff.formType.toLowerCase() === 'selector') {
                                                            if ($(this).attr('data-name') == ff.name && g.flexiform.option.onSubmit.updateRow) {
                                                                var displaytxt = fo[ff.name].formElement.children().find('li.liSelected').find('div').text();
                                                                $('#' + btnid).closest('tr').children().eq(ie).find('div').text(displaytxt);
                                                            };
                                                        } else {
                                                            if ($(this).attr('data-name') == ff.name) {
                                                                $('#' + btnid).closest('tr').children().eq(ie).find('div').text(fo[ff.name].formElement.val());
                                                            };
                                                        };
                                                    });
                                                };
                                            };
                                        };
                                    }, 800);
                                };
                                //do user task 
                                if (g.flexiform.option.onSubmit.action) {
                                    g.flexiform.option.onSubmit.action(data, g.flexiform.formObject);
                                };

                                //close form                                
                                if (g.flexiform.option.onSubmit.close) {
                                    g.flexiform.close();
                                };
                            } else {
                                //unknown return. 
                                fo.loadingIcon.hide();
                                fo.formStatus.text('').css('color', '#000');
                            };
                            data = null;
                        });
                        req.fail(function () {
                            fo.loadingIcon.hide();
                            fo.formStatus.css('color', 'red').text(g.flexiform.option.errormsg);
                        });
                    };
                }
            },
            pager: 0
        };

        if (p.colModel) { //create model if any
            thead = document.createElement('thead');
            var tr = document.createElement('tr');
            for (var i = 0; i < p.colModel.length; i++) {
                var cm = p.colModel[i];
                var th = document.createElement('th');
                th.innerHTML = cm.display;
                if (cm.name && cm.sortable) {
                    $(th).attr('abbr', cm.name);
                }
                //add column name to th
                $(th).attr('data-name', cm.name);

                $(th).attr('axis', 'col' + i);
                if (cm.align) {
                    th.align = cm.align;
                }
                if (cm.width) {
                    $(th).attr('width', cm.width);
                }
                //disable hide for command column
                if ($(cm).attr('hide') && cm.name != 'command') {
                    th.hidden = true;
                }
                if (cm.process) {
                    th.process = cm.process;
                }
                $(tr).append(th);
            }
            $(thead).append(tr);
            $(t).prepend(thead);
        } // end if p.colmodel
        //init divs
        g.gDiv = document.createElement('div'); //create global container
        g.mDiv = document.createElement('div'); //create title container
        g.hDiv = document.createElement('div'); //create header container
        g.bDiv = document.createElement('div'); //create body container
        g.vDiv = document.createElement('div'); //create grip
        g.rDiv = document.createElement('div'); //create horizontal resizer
        g.cDrag = document.createElement('div'); //create column drag
        g.block = document.createElement('div'); //creat blocker
        g.nDiv = document.createElement('div'); //create column show/hide popup
        g.nBtn = document.createElement('div'); //create column show/hide button
        g.iDiv = document.createElement('div'); //create editable layer
        g.tDiv = document.createElement('div'); //create toolbar
        g.sDiv = document.createElement('div');
        g.pDiv = document.createElement('div'); //create pager container
        if (!p.usepager) {
            g.pDiv.style.display = 'none';
        }
        g.hTable = document.createElement('table');
        g.gDiv.className = 'flexigrid';
        if (p.width != 'auto') {
            g.gDiv.style.width = p.width + 'px';
        }
        //add conditional classes
        if ($.browser.msie) {
            $(g.gDiv).addClass('ie');
        }
        if (p.novstripe) {
            $(g.gDiv).addClass('novstripe');
        }
        $(t).before(g.gDiv);
        $(g.gDiv).append(t);
        //set toolbar
        if (p.buttons) {
            g.tDiv.className = 'tDiv';
            var tDiv2 = document.createElement('div');
            tDiv2.className = 'tDiv2';
            for (var i = 0; i < p.buttons.length; i++) {
                var btn = p.buttons[i];
                if (!btn.separator) {
                    var btnDiv = document.createElement('div');
                    btnDiv.className = 'fbutton';
                    btnDiv.innerHTML = "<div><span>" + btn.name + "</span></div>";
                    if (btn.bclass) $('span', btnDiv).addClass(btn.bclass).css({
                        paddingLeft: 20
                    });
                    btnDiv.onpress = btn.onpress;
                    btnDiv.name = btn.name;
                    if (btn.onpress) {
                        $(btnDiv).click(function () {
                            this.onpress(this.name, g.gDiv);
                        });
                    }
                    $(tDiv2).append(btnDiv);
                    if ($.browser.msie && $.browser.version < 7.0) {
                        $(btnDiv).hover(function () {
                            $(this).addClass('fbOver');
                        }, function () {
                            $(this).removeClass('fbOver');
                        });
                    }
                } else {
                    $(tDiv2).append("<div class='btnseparator'></div>");
                }
            }
            $(g.tDiv).append(tDiv2);
            $(g.tDiv).append("<div style='clear:both'></div>");
            $(g.gDiv).prepend(g.tDiv);
        }
        g.hDiv.className = 'hDiv';
        $(t).before(g.hDiv);
        g.hTable.cellPadding = 0;
        g.hTable.cellSpacing = 0;
        $(g.hDiv).append('<div class="hDivBox"></div>');
        $('div', g.hDiv).append(g.hTable);
        var thead = $("thead:first", t).get(0);
        if (thead) $(g.hTable).append(thead);
        thead = null;
        if (!p.colmodel) var ci = 0;
        $('thead tr:first th', g.hDiv).each(function () {
            var thdiv = document.createElement('div');
            if ($(this).attr('abbr')) {
                $(this).click(function (e) {
                    if (!$(this).hasClass('thOver')) return false;
                    var obj = (e.target || e.srcElement);
                    if (obj.href || obj.type) return true;
                    g.changeSort(this);
                });
                if ($(this).attr('abbr') == p.sortname) {
                    this.className = 'sorted';
                    thdiv.className = 's' + p.sortorder;
                }
            }
            if (this.hidden) {
                $(this).hide();
            }
            if (!p.colmodel) {
                $(this).attr('axis', 'col' + ci++);
            }
            $(thdiv).css({
                textAlign: this.align,
                width: this.width + 'px'
            });
            thdiv.innerHTML = this.innerHTML;
            $(this).empty().append(thdiv).removeAttr('width').mousedown(function (e) {
                g.dragStart('colMove', e, this);
            }).hover(function () {
                //disable column sort for command column
                if ($(this).attr('data-name') != 'command') {
                    if (!g.colresize && !$(this).hasClass('thMove') && !g.colCopy) {
                        $(this).addClass('thOver');
                    };

                    if ($(this).attr('abbr') != p.sortname && !g.colCopy && !g.colresize && $(this).attr('abbr')) {
                        $('div', this).addClass('s' + p.sortorder);
                    } else if ($(this).attr('abbr') == p.sortname && !g.colCopy && !g.colresize && $(this).attr('abbr')) {
                        var no = (p.sortorder == 'asc') ? 'desc' : 'asc';
                        $('div', this).removeClass('s' + p.sortorder).addClass('s' + no);
                    };
                };
                if (g.colCopy) {
                    var n = $('th', g.hDiv).index(this);
                    if (n == g.dcoln) {
                        return false;
                    };
                    if (n < g.dcoln) {
                        $(this).append(g.cdropleft);
                    } else {
                        $(this).append(g.cdropright);
                    };
                    g.dcolt = n;
                } else if (!g.colresize) {
                    var nv = $('th:visible', g.hDiv).index(this);
                    var onl = parseInt($('div:eq(' + nv + ')', g.cDrag).css('left'));
                    var nw = jQuery(g.nBtn).outerWidth();
                    var nl = onl - nw + Math.floor(p.cgwidth / 2);
                    $(g.nDiv).hide();
                    $(g.nBtn).hide();
                    //disable column show/hide menu.
                    if ($(this).attr('data-name') !== 'command') {
                        $(g.nBtn).css({
                            'left': nl,
                            top: g.hDiv.offsetTop
                        }).show();

                        var ndw = parseInt($(g.nDiv).width());
                        $(g.nDiv).css({
                            top: g.bDiv.offsetTop
                        });
                        if ((nl + ndw) > $(g.gDiv).width()) {
                            $(g.nDiv).css('left', onl - ndw + 1);
                        } else {
                            $(g.nDiv).css('left', nl);
                        };
                        if ($(this).hasClass('sorted')) {
                            $(g.nBtn).addClass('srtd');
                        } else {
                            $(g.nBtn).removeClass('srtd');
                        };
                    };
                };
            }, function () {
                $(this).removeClass('thOver');
                if ($(this).attr('abbr') != p.sortname) {
                    $('div', this).removeClass('s' + p.sortorder);
                } else if ($(this).attr('abbr') == p.sortname) {
                    var no = (p.sortorder == 'asc') ? 'desc' : 'asc';
                    $('div', this).addClass('s' + p.sortorder).removeClass('s' + no);
                }
                if (g.colCopy) {
                    $(g.cdropleft).remove();
                    $(g.cdropright).remove();
                    g.dcolt = null;
                }
            }); //wrap content
        });

        //set bDiv
        g.bDiv.className = 'bDiv';
        $(t).before(g.bDiv);
        $(g.bDiv).css({
            height: (p.height == 'auto') ? 'auto' : p.height + "px"
        }).scroll(function (e) {
            g.scroll()
        }).append(t);
        if (p.height == 'auto') {
            $('table', g.bDiv).addClass('autoht');
        }
        //add td & row properties
        g.addCellProp();
        g.addRowProp();
        //set cDrag
        var cdcol = $('thead tr:first th:first', g.hDiv).get(0);
        if (cdcol != null) {
            g.cDrag.className = 'cDrag';
            g.cdpad = 0;
            g.cdpad += (isNaN(parseInt($('div', cdcol).css('borderLeftWidth'))) ? 0 : parseInt($('div', cdcol).css('borderLeftWidth')));
            g.cdpad += (isNaN(parseInt($('div', cdcol).css('borderRightWidth'))) ? 0 : parseInt($('div', cdcol).css('borderRightWidth')));
            g.cdpad += (isNaN(parseInt($('div', cdcol).css('paddingLeft'))) ? 0 : parseInt($('div', cdcol).css('paddingLeft')));
            g.cdpad += (isNaN(parseInt($('div', cdcol).css('paddingRight'))) ? 0 : parseInt($('div', cdcol).css('paddingRight')));
            g.cdpad += (isNaN(parseInt($(cdcol).css('borderLeftWidth'))) ? 0 : parseInt($(cdcol).css('borderLeftWidth')));
            g.cdpad += (isNaN(parseInt($(cdcol).css('borderRightWidth'))) ? 0 : parseInt($(cdcol).css('borderRightWidth')));
            g.cdpad += (isNaN(parseInt($(cdcol).css('paddingLeft'))) ? 0 : parseInt($(cdcol).css('paddingLeft')));
            g.cdpad += (isNaN(parseInt($(cdcol).css('paddingRight'))) ? 0 : parseInt($(cdcol).css('paddingRight')));
            $(g.bDiv).before(g.cDrag);
            var cdheight = $(g.bDiv).height();
            var hdheight = $(g.hDiv).height();
            $(g.cDrag).css({
                top: -hdheight + 'px'
            });
            $('thead tr:first th', g.hDiv).each(function () {
                var cgDiv = document.createElement('div');
                $(g.cDrag).append(cgDiv);
                if (!p.cgwidth) {
                    p.cgwidth = $(cgDiv).width();
                }
                $(cgDiv).css({
                    height: cdheight + hdheight
                }).mousedown(function (e) {
                    g.dragStart('colresize', e, this);
                });
                if ($.browser.msie && $.browser.version < 7.0) {
                    g.fixHeight($(g.gDiv).height());
                    $(cgDiv).hover(function () {
                        g.fixHeight();
                        $(this).addClass('dragging')
                    }, function () {
                        if (!g.colresize) $(this).removeClass('dragging')
                    });
                }
            });
        }
        //add strip
        if (p.striped) {
            $('tbody tr:odd', g.bDiv).addClass('erow');
        }
        if (p.resizable && p.height != 'auto') {
            g.vDiv.className = 'vGrip';
            $(g.vDiv).mousedown(function (e) {
                g.dragStart('vresize', e)
            }).html('<span></span>');
            $(g.bDiv).after(g.vDiv);
        }
        if (p.resizable && p.width != 'auto' && !p.nohresize) {
            g.rDiv.className = 'hGrip';
            $(g.rDiv).mousedown(function (e) {
                g.dragStart('vresize', e, true);
            }).html('<span></span>').css('height', $(g.gDiv).height());
            if ($.browser.msie && $.browser.version < 7.0) {
                $(g.rDiv).hover(function () {
                    $(this).addClass('hgOver');
                }, function () {
                    $(this).removeClass('hgOver');
                });
            }
            $(g.gDiv).append(g.rDiv);
        }
        // add pager
        if (p.usepager) {
            g.pDiv.className = 'pDiv';
            g.pDiv.innerHTML = '<div class="pDiv2"></div>';
            $(g.bDiv).after(g.pDiv);
            var html = ' <div class="pGroup"> <div class="pFirst pButton"><span></span></div><div class="pPrev pButton"><span></span></div> </div> <div class="btnseparator"></div> <div class="pGroup"><span class="pcontrol">' + p.pagetext + ' <input type="text" size="4" value="1" /> ' + p.outof + ' <span> 1 </span></span></div> <div class="btnseparator"></div> <div class="pGroup"> <div class="pNext pButton"><span></span></div><div class="pLast pButton"><span></span></div> </div> <div class="btnseparator"></div> <div class="pGroup"> <div class="pReload pButton"><span></span></div> </div> <div class="btnseparator"></div> <div class="pGroup"><span class="pPageStat"></span></div>';
            $('div', g.pDiv).html(html);
            $('.pReload', g.pDiv).click(function () {
                g.populate()
            });
            $('.pFirst', g.pDiv).click(function () {
                g.changePage('first')
            });
            $('.pPrev', g.pDiv).click(function () {
                g.changePage('prev')
            });
            $('.pNext', g.pDiv).click(function () {
                g.changePage('next')
            });
            $('.pLast', g.pDiv).click(function () {
                g.changePage('last')
            });
            $('.pcontrol input', g.pDiv).keydown(function (e) {
                if (e.keyCode == 13) g.changePage('input')
            });
            if ($.browser.msie && $.browser.version < 7) $('.pButton', g.pDiv).hover(function () {
                $(this).addClass('pBtnOver');
            }, function () {
                $(this).removeClass('pBtnOver');
            });
            if (p.useRp) {
                var opt = '',
					sel = '';
                for (var nx = 0; nx < p.rpOptions.length; nx++) {
                    if (p.rp == p.rpOptions[nx]) sel = 'selected="selected"';
                    else sel = '';
                    opt += "<option value='" + p.rpOptions[nx] + "' " + sel + " >" + p.rpOptions[nx] + "&nbsp;&nbsp;</option>";
                }
                $('.pDiv2', g.pDiv).prepend("<div class='pGroup'><select name='rp'>" + opt + "</select></div> <div class='btnseparator'></div>");
                $('select', g.pDiv).change(function () {
                    if (p.onRpChange) {
                        p.onRpChange(+this.value);
                    } else {
                        p.newp = 1;
                        p.rp = +this.value;
                        g.populate();
                    }
                });
            }
            //add search button
            if (p.searchitems) {
                $('.pDiv2', g.pDiv).prepend("<div class='pGroup'> <div class='pSearch pButton'><span></span></div> </div>  <div class='btnseparator'></div>");
                $('.pSearch', g.pDiv).click(function () {
                    $(g.sDiv).slideToggle('fast', function () {
                        $('.sDiv:visible input:first', g.gDiv).trigger('focus');
                    });
                });
                //add search box
                g.sDiv.className = 'sDiv';
                var sitems = p.searchitems;

                var sopt = '', sel = '';
                for (var s = 0; s < sitems.length; s++) {
                    if (p.qtype == '' && sitems[s].isdefault == true) {
                        p.qtype = sitems[s].name;
                        sel = 'selected="selected"';
                    } else {
                        sel = '';
                    }
                    sopt += "<option value='" + sitems[s].name + "' " + sel + " >" + sitems[s].display + "&nbsp;&nbsp;</option>";
                };
                if (p.qtype == '') {
                    p.qtype = sitems[0].name;
                };

                $(g.sDiv).append("<div class='sDiv2'><div style='float:left;'>" + p.findtext +
						" <input type='text' value='" + p.query + "' size='30' name='q' class='qsbox' /> " +
						" <select name='qtype'>" + sopt + "</select>" +
                        " <div></div><div style='clear:both;'></div>");

                //customize, adding search button
                var sbtn = document.createElement('div');
                sbtn.className = 'fbutton';
                sbtn.innerHTML = "<div><span class='searchbtn' style='padding-left:20px;'>" + p.searchbtn + "</span></div>";
                if ($.browser.msie && $.browser.version < 7.0) {
                    $(sbtn).hover(function () {
                        $(this).addClass('fbOver');
                    }, function () {
                        $(this).removeClass('fbOver');
                    });
                }

                $(g.sDiv).find('div.sDiv2').append(sbtn);

                $(sbtn).click(function () {
                    g.doSearch();
                });

                $('input[value=Clear]', g.sDiv).click(function () {
                    $('input[name=q]', g.sDiv).val('');
                    p.query = '';
                    g.doSearch();
                });
                $(g.bDiv).after(g.sDiv);
            }
        }
        $(g.pDiv, g.sDiv).append("<div style='clear:both'></div>");
        // add title
        if (p.title) {
            g.mDiv.className = 'mDiv';
            g.mDiv.innerHTML = '<div class="ftitle">' + p.title + '</div>';
            $(g.gDiv).prepend(g.mDiv);
            if (p.showTableToggleBtn) {
                $(g.mDiv).append('<div class="ptogtitle" title="Minimize/Maximize Table"><span></span></div>');
                $('div.ptogtitle', g.mDiv).click(function () {
                    $(g.gDiv).toggleClass('hideBody');
                    $(this).toggleClass('vsble');
                });
            }
        }
        //setup cdrops
        g.cdropleft = document.createElement('span');
        g.cdropleft.className = 'cdropleft';
        g.cdropright = document.createElement('span');
        g.cdropright.className = 'cdropright';
        //add block
        g.block.className = 'gBlock';
        var gh = $(g.bDiv).height();
        var gtop = g.bDiv.offsetTop;
        $(g.block).css({
            width: g.bDiv.style.width,
            height: gh,
            background: 'white',
            position: 'relative',
            marginBottom: (gh * -1),
            zIndex: 1,
            top: gtop,
            left: '0px'
        });
        $(g.block).fadeTo(0, p.blockOpacity);
        // add column control
        if ($('th', g.hDiv).length) {
            g.nDiv.className = 'nDiv';
            g.nDiv.innerHTML = "<table cellpadding='0' cellspacing='0'><tbody></tbody></table>";
            $(g.nDiv).css({
                marginBottom: (gh * -1),
                display: 'none',
                top: gtop
            }); //.noSelect();
            var cn = 0;
            $('th div', g.hDiv).each(function () {
                //disable command column from show/hide menu
                if ($(this).parent().attr('data-name') !== 'command') {
                    var kcol = $("th[axis='col" + cn + "']", g.hDiv)[0];
                    var chk = 'checked="checked"';
                    if (kcol.style.display == 'none') {
                        chk = '';
                    }
                    $('tbody', g.nDiv).append('<tr><td class="ndcol1"><input type="checkbox" ' + chk + ' class="togCol" value="' + cn + '" /></td><td class="ndcol2">' + this.innerHTML + '</td></tr>');
                };
                cn++;
            });
            if ($.browser.msie && $.browser.version < 7.0) $('tr', g.nDiv).hover(function () {
                $(this).addClass('ndcolover');
            }, function () {
                $(this).removeClass('ndcolover');
            });
            $('td.ndcol2', g.nDiv).click(function () {
                if ($('input:checked', g.nDiv).length <= p.minColToggle && $(this).prev().find('input')[0].checked) return false;
                return g.toggleCol($(this).prev().find('input').val());
            });
            $('input.togCol', g.nDiv).click(function () {
                if ($('input:checked', g.nDiv).length < p.minColToggle && this.checked == false) return false;
                $(this).parent().next().trigger('click');
            });
            $(g.gDiv).prepend(g.nDiv);
            $(g.nBtn).addClass('nBtn')
				.html('<div></div>')
				.attr('title', 'Hide/Show Columns')
				.click(function () {
				    $(g.nDiv).toggle();
				    return true;
				}
			);
            if (p.showToggleBtn) {
                $(g.gDiv).prepend(g.nBtn);
            }
        }
        // add date edit layer
        $(g.iDiv).addClass('iDiv').css({
            display: 'none'
        });
        $(g.bDiv).append(g.iDiv);
        // add flexigrid events
        $(g.bDiv).hover(function () {
            $(g.nDiv).hide();
            $(g.nBtn).hide();
        }, function () {
            if (g.multisel) {
                g.multisel = false;
            }
        });
        $(g.gDiv).hover(function () { }, function () {
            $(g.nDiv).hide();
            $(g.nBtn).hide();
        });
        //add document events
        $(document).mousemove(function (e) {
            g.dragMove(e)
        }).mouseup(function (e) {
            g.dragEnd()
        }).hover(function () { }, function () {
            g.dragEnd()
        });
        //browser adjustments
        if ($.browser.msie && $.browser.version < 7.0) {
            $('.hDiv,.bDiv,.mDiv,.pDiv,.vGrip,.tDiv, .sDiv', g.gDiv).css({
                width: '100%'
            });
            $(g.gDiv).addClass('ie6');
            if (p.width != 'auto') {
                $(g.gDiv).addClass('ie6fullwidthbug');
            }
        }
        g.rePosDrag();
        g.fixHeight();

        //make grid functions accessible
        t.p = p;
        t.grid = g;
        // load data
        if (p.url && p.autoload) {
            g.populate();
        }
        return t;
    };
    var docloaded = false;
    $(document).ready(function () {
        docloaded = true
    });
    $.fn.flexigrid = function (p) {
        return this.each(function () {
            if (!docloaded) {
                $(this).hide();
                var t = this;
                $(document).ready(function () {
                    $.addFlex(t, p);
                });
            } else {
                $.addFlex(this, p);
            }
        });
    }; //end flexigrid
    $.fn.flexReload = function (p) { // function to reload grid
        return this.each(function () {
            if (this.grid && this.p.url) this.grid.populate();
        });
    }; //end flexReload
    $.fn.flexOptions = function (p) { //function to update general options
        return this.each(function () {
            if (this.grid) $.extend(this.p, p);
        });
    }; //end flexOptions
    $.fn.flexToggleCol = function (cid, visible) { // function to toggle column
        return this.each(function () {
            if (this.grid) this.grid.toggleCol(cid, visible);
        });
    }; //end flexToggleCol
    $.fn.flexAddData = function (data) { // function to add data to grid
        return this.each(function () {
            if (this.grid) this.grid.addData(data);
        });
    };
    $.fn.flexiModal = function (settings) {
        return this.each(function () {
            if (this.grid) this.grid.fleximodal.open(settings);
        });
    };

    $.fn.flexiForm = function (settings) {
        return this.each(function () {
            if (this.grid) {
                this.grid.flexiform.option = $.extend(this.grid.flexiform.option, this.p.flexiform, settings);
                this.grid.flexiform.newForm = true;
                this.grid.flexiform.open();
            };
        });
    };

})(jQuery);